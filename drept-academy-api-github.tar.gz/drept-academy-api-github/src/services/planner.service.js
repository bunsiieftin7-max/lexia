const { query } = require('../config/database');
const logger = require('../utils/logger');
const notificationService = require('./notification.service');

class PlannerService {
  /**
   * Génère un plan d'apprentissage quotidien pour tous les utilisateurs actifs
   */
  async generateDailyPlans() {
    try {
      // Récupérer les utilisateurs actifs sans plan aujourd'hui
      const usersQuery = `
        SELECT 
          u.wp_user_id,
          u.wp_display_name,
          u.email,
          us.last_activity,
          ust.current_streak,
          lp.preferred_time,
          lp.preferred_duration_minutes,
          lp.enable_daily_reminder
        FROM users u
        JOIN user_stats us ON u.wp_user_id = us.wp_user_id
        LEFT JOIN user_streaks ust ON u.wp_user_id = ust.wp_user_id
        LEFT JOIN learning_profiles lp ON u.wp_user_id = lp.wp_user_id
        WHERE 
          us.last_activity > NOW() - INTERVAL '30 days'
          AND (lp.enable_daily_reminder = true OR lp.enable_daily_reminder IS NULL)
          AND NOT EXISTS (
            SELECT 1 FROM daily_plans dp 
            WHERE dp.wp_user_id = u.wp_user_id 
            AND dp.plan_date = CURRENT_DATE
          )
        LIMIT 100;
      `;

      const usersResult = await query(usersQuery);
      const plansCreated = [];

      for (const user of usersResult.rows) {
        try {
          const plan = await this.generatePlanForUser(user);
          plansCreated.push(plan);
        } catch (error) {
          logger.error(`Erreur lors de la génération du plan pour l'utilisateur ${user.wp_user_id}:`, error);
        }
      }

      logger.info(`Plans quotidiens générés: ${plansCreated.length}`);

      return {
        success: true,
        plans_created: plansCreated.length,
        plans: plansCreated
      };
    } catch (error) {
      logger.error('Erreur lors de la génération des plans quotidiens:', error);
      throw error;
    }
  }

  /**
   * Génère un plan personnalisé pour un utilisateur
   */
  async generatePlanForUser(user) {
    try {
      // Récupérer les sujets faibles de l'utilisateur
      const weakSubjectsQuery = `
        SELECT 
          usp.subject_id,
          s.name as subject_name,
          usp.success_rate,
          usp.total_questions_answered
        FROM user_subject_progress usp
        JOIN subjects s ON usp.subject_id = s.id
        WHERE usp.wp_user_id = $1
        ORDER BY usp.success_rate ASC, usp.total_questions_answered ASC
        LIMIT 3;
      `;

      const subjectsResult = await query(weakSubjectsQuery, [user.wp_user_id]);
      const subjects = subjectsResult.rows;

      // Sujets par défaut si l'utilisateur n'a pas encore d'historique
      const prioritySubject = subjects[0] || { 
        subject_id: 1, 
        subject_name: 'Droit Civil' 
      };
      const secondSubject = subjects[1] || { 
        subject_id: 2, 
        subject_name: 'Droit Pénal' 
      };

      // Durée préférée ou 15 minutes par défaut
      const duration = user.preferred_duration_minutes || 15;

      // Créer les activités du plan
      const morningActivity = {
        time: user.preferred_time || "08:00",
        activity: "FLASHCARD",
        subject_id: prioritySubject.subject_id,
        subject_name: prioritySubject.subject_name,
        duration_minutes: duration,
        questions_count: 10,
        difficulty: (prioritySubject.success_rate || 50) < 50 ? "facile" : "moyen"
      };

      const afternoonActivity = {
        time: "14:00",
        activity: "CHATBOT",
        subject_name: "Révision mixte",
        duration_minutes: Math.round(duration * 1.3),
        focus: "Concepts mal compris récemment"
      };

      const eveningActivity = {
        time: "20:00",
        activity: "QCM",
        subject_id: secondSubject.subject_id,
        subject_name: secondSubject.subject_name,
        duration_minutes: duration,
        questions_count: 15,
        difficulty: "moyen"
      };

      // Sauvegarder le plan
      const savePlanQuery = `
        INSERT INTO daily_plans (
          wp_user_id,
          plan_date,
          morning_activity,
          afternoon_activity,
          evening_activity,
          morning_completed,
          afternoon_completed,
          evening_completed,
          created_at
        ) VALUES ($1, CURRENT_DATE, $2, $3, $4, false, false, false, NOW())
        RETURNING *;
      `;

      const planResult = await query(savePlanQuery, [
        user.wp_user_id,
        JSON.stringify(morningActivity),
        JSON.stringify(afternoonActivity),
        JSON.stringify(eveningActivity)
      ]);

      // Créer une notification
      await notificationService.createNotification({
        wp_user_id: user.wp_user_id,
        notification_type: 'daily_plan_ready',
        title: '📅 Ton programme du jour est prêt !',
        message: '3 sessions d\'apprentissage planifiées pour aujourd\'hui',
        priority: 'normal',
        data: {
          has_plan: true,
          streak: user.current_streak || 0,
          action: 'VIEW_PLAN'
        }
      });

      logger.info('Plan quotidien créé', {
        user: user.wp_user_id,
        date: new Date().toISOString().split('T')[0]
      });

      return planResult.rows[0];
    } catch (error) {
      logger.error('Erreur lors de la génération du plan utilisateur:', error);
      throw error;
    }
  }

  /**
   * Récupère le plan du jour d'un utilisateur
   */
  async getTodayPlan(wp_user_id) {
    try {
      const query_text = `
        SELECT *
        FROM daily_plans
        WHERE wp_user_id = $1 AND plan_date = CURRENT_DATE;
      `;

      const result = await query(query_text, [wp_user_id]);

      if (result.rows.length === 0) {
        return {
          success: false,
          message: 'Aucun plan pour aujourd\'hui'
        };
      }

      const plan = result.rows[0];

      // Parser les activités JSON
      return {
        success: true,
        plan: {
          ...plan,
          morning_activity: this.safeJsonParse(plan.morning_activity),
          afternoon_activity: this.safeJsonParse(plan.afternoon_activity),
          evening_activity: this.safeJsonParse(plan.evening_activity)
        }
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération du plan:', error);
      throw error;
    }
  }

  /**
   * Marque une activité comme complétée
   */
  async markActivityCompleted(wp_user_id, activityType) {
    try {
      const validTypes = ['morning', 'afternoon', 'evening'];
      if (!validTypes.includes(activityType)) {
        throw new Error('Type d\'activité invalide');
      }

      const query_text = `
        UPDATE daily_plans
        SET ${activityType}_completed = true,
            updated_at = NOW()
        WHERE wp_user_id = $1 AND plan_date = CURRENT_DATE
        RETURNING *;
      `;

      const result = await query(query_text, [wp_user_id]);

      if (result.rowCount === 0) {
        return {
          success: false,
          message: 'Aucun plan trouvé pour aujourd\'hui'
        };
      }

      logger.info('Activité marquée comme complétée', {
        user: wp_user_id,
        activity: activityType
      });

      return {
        success: true,
        plan: result.rows[0]
      };
    } catch (error) {
      logger.error('Erreur lors du marquage de l\'activité:', error);
      throw error;
    }
  }

  /**
   * Parse JSON de manière sécurisée
   */
  safeJsonParse(jsonString, defaultValue = {}) {
    if (!jsonString) return defaultValue;
    try {
      return typeof jsonString === 'string' ? JSON.parse(jsonString) : jsonString;
    } catch (e) {
      logger.warn('Erreur lors du parsing JSON:', e);
      return defaultValue;
    }
  }

  /**
   * Récupère les statistiques de complétion des plans
   */
  async getPlanStats(wp_user_id, days = 7) {
    try {
      const query_text = `
        SELECT 
          COUNT(*) as total_days,
          SUM(CASE WHEN morning_completed THEN 1 ELSE 0 END) as morning_completed,
          SUM(CASE WHEN afternoon_completed THEN 1 ELSE 0 END) as afternoon_completed,
          SUM(CASE WHEN evening_completed THEN 1 ELSE 0 END) as evening_completed,
          SUM(CASE WHEN morning_completed AND afternoon_completed AND evening_completed THEN 1 ELSE 0 END) as perfect_days
        FROM daily_plans
        WHERE wp_user_id = $1
          AND plan_date >= CURRENT_DATE - INTERVAL '${days} days'
          AND plan_date <= CURRENT_DATE;
      `;

      const result = await query(query_text, [wp_user_id]);

      return {
        success: true,
        stats: result.rows[0]
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération des stats de plan:', error);
      throw error;
    }
  }
}

module.exports = new PlannerService();
