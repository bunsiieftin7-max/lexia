const { query, transaction } = require('../config/database');
const logger = require('../utils/logger');
const notificationService = require('./notification.service');

class BadgeService {
  /**
   * Récupère tous les badges d'un utilisateur (débloqués et verrouillés)
   */
  async getUserBadges(wp_user_id) {
    try {
      const query_text = `
        SELECT 
          b.id,
          b.code,
          b.name,
          b.description,
          b.icon_emoji,
          b.xp_reward,
          b.rarity,
          ub.unlocked_at,
          CASE WHEN ub.id IS NOT NULL THEN true ELSE false END as is_unlocked
        FROM badges b
        LEFT JOIN user_badges ub ON b.id = ub.badge_id AND ub.wp_user_id = $1
        ORDER BY 
          CASE WHEN ub.id IS NOT NULL THEN 0 ELSE 1 END,
          b.xp_reward DESC,
          b.name ASC;
      `;

      const result = await query(query_text, [wp_user_id]);

      const badges = result.rows.map(b => ({
        id: b.id,
        code: b.code,
        name: b.name,
        description: b.description,
        icon: b.icon_emoji || '🏅',
        xp_reward: b.xp_reward,
        rarity: b.rarity,
        is_unlocked: b.is_unlocked,
        unlocked_at: b.unlocked_at
      }));

      const unlockedCount = badges.filter(b => b.is_unlocked).length;
      const totalCount = badges.length;
      const progressPercent = totalCount > 0 ? Math.round((unlockedCount / totalCount) * 100) : 0;

      return {
        success: true,
        badges,
        stats: {
          total_badges: totalCount,
          unlocked_count: unlockedCount,
          locked_count: totalCount - unlockedCount,
          progress_percent: progressPercent
        }
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération des badges:', error);
      throw error;
    }
  }

  /**
   * Vérifie et débloque les badges potentiels pour un utilisateur
   */
  async checkAndUnlockBadges(wp_user_id) {
    try {
      // Récupérer les stats de l'utilisateur
      const statsQuery = `
        SELECT 
          us.*,
          ust.current_streak,
          ust.longest_streak
        FROM user_stats us
        LEFT JOIN user_streaks ust ON us.wp_user_id = ust.wp_user_id
        WHERE us.wp_user_id = $1;
      `;

      const statsResult = await query(statsQuery, [wp_user_id]);
      
      if (statsResult.rows.length === 0) {
        return { success: false, message: 'Utilisateur non trouvé' };
      }

      const stats = statsResult.rows[0];
      const newBadges = [];

      // Définir les règles de badges
      const badgeRules = [
        {
          code: 'FIRST_QUESTION',
          condition: stats.total_questions_answered >= 1,
          name: 'Première Question',
          description: 'Répondre à votre première question',
          icon: '🎯',
          xp: 10,
          rarity: 'common'
        },
        {
          code: 'QUESTIONS_10',
          condition: stats.total_questions_answered >= 10,
          name: '10 Questions',
          description: 'Répondre à 10 questions',
          icon: '📚',
          xp: 25,
          rarity: 'common'
        },
        {
          code: 'QUESTIONS_50',
          condition: stats.total_questions_answered >= 50,
          name: '50 Questions',
          description: 'Répondre à 50 questions',
          icon: '🎓',
          xp: 50,
          rarity: 'uncommon'
        },
        {
          code: 'QUESTIONS_100',
          condition: stats.total_questions_answered >= 100,
          name: '100 Questions',
          description: 'Répondre à 100 questions',
          icon: '🌟',
          xp: 100,
          rarity: 'rare'
        },
        {
          code: 'QUESTIONS_500',
          condition: stats.total_questions_answered >= 500,
          name: 'Expert',
          description: 'Répondre à 500 questions',
          icon: '👑',
          xp: 250,
          rarity: 'epic'
        },
        {
          code: 'STREAK_7',
          condition: stats.current_streak >= 7,
          name: 'Série de 7 jours',
          description: 'Apprendre 7 jours consécutifs',
          icon: '🔥',
          xp: 75,
          rarity: 'uncommon'
        },
        {
          code: 'STREAK_30',
          condition: stats.current_streak >= 30,
          name: 'Série de 30 jours',
          description: 'Apprendre 30 jours consécutifs',
          icon: '⚡',
          xp: 200,
          rarity: 'epic'
        },
        {
          code: 'STREAK_100',
          condition: stats.current_streak >= 100,
          name: 'Centurion',
          description: 'Apprendre 100 jours consécutifs',
          icon: '💎',
          xp: 500,
          rarity: 'legendary'
        },
        {
          code: 'PERFECTIONIST',
          condition: stats.success_rate >= 90 && stats.total_questions_answered >= 50,
          name: 'Perfectionniste',
          description: '90% de réussite sur 50+ questions',
          icon: '✨',
          xp: 150,
          rarity: 'rare'
        },
        {
          code: 'LEVEL_5',
          condition: stats.current_level >= 5,
          name: 'Niveau 5',
          description: 'Atteindre le niveau 5',
          icon: '⭐',
          xp: 50,
          rarity: 'common'
        },
        {
          code: 'LEVEL_10',
          condition: stats.current_level >= 10,
          name: 'Niveau 10',
          description: 'Atteindre le niveau 10',
          icon: '🌠',
          xp: 150,
          rarity: 'rare'
        }
      ];

      // Vérifier chaque badge
      for (const rule of badgeRules) {
        if (rule.condition) {
          const unlocked = await this.unlockBadge(wp_user_id, rule);
          if (unlocked) {
            newBadges.push(unlocked);
          }
        }
      }

      if (newBadges.length > 0) {
        logger.info(`${newBadges.length} nouveau(x) badge(s) débloqué(s)`, {
          user: wp_user_id,
          badges: newBadges.map(b => b.code)
        });
      }

      return {
        success: true,
        new_badges: newBadges,
        count: newBadges.length
      };
    } catch (error) {
      logger.error('Erreur lors de la vérification des badges:', error);
      throw error;
    }
  }

  /**
   * Débloque un badge spécifique
   */
  async unlockBadge(wp_user_id, badgeData) {
    try {
      return await transaction(async (client) => {
        // Vérifier si le badge existe déjà
        const checkBadgeQuery = `
          SELECT id FROM badges WHERE code = $1;
        `;
        const checkResult = await client.query(checkBadgeQuery, [badgeData.code]);

        let badgeId;
        
        if (checkResult.rows.length === 0) {
          // Créer le badge s'il n'existe pas
          const createBadgeQuery = `
            INSERT INTO badges (code, name, description, icon_emoji, xp_reward, rarity)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id;
          `;
          const createResult = await client.query(createBadgeQuery, [
            badgeData.code,
            badgeData.name,
            badgeData.description,
            badgeData.icon,
            badgeData.xp,
            badgeData.rarity
          ]);
          badgeId = createResult.rows[0].id;
        } else {
          badgeId = checkResult.rows[0].id;
        }

        // Vérifier si l'utilisateur a déjà ce badge
        const checkUserBadgeQuery = `
          SELECT id FROM user_badges 
          WHERE wp_user_id = $1 AND badge_id = $2;
        `;
        const userBadgeCheck = await client.query(checkUserBadgeQuery, [wp_user_id, badgeId]);

        if (userBadgeCheck.rows.length > 0) {
          return null; // Badge déjà débloqué
        }

        // Débloquer le badge
        const unlockQuery = `
          INSERT INTO user_badges (wp_user_id, badge_id, unlocked_at)
          VALUES ($1, $2, NOW())
          RETURNING *;
        `;
        await client.query(unlockQuery, [wp_user_id, badgeId]);

        // Ajouter l'XP bonus
        const xpQuery = `
          UPDATE user_stats
          SET total_xp = total_xp + $1,
              current_level = FLOOR((total_xp + $1) / 100) + 1
          WHERE wp_user_id = $2;
        `;
        await client.query(xpQuery, [badgeData.xp, wp_user_id]);

        // Créer une notification
        await notificationService.createNotification({
          wp_user_id,
          notification_type: 'badge_unlocked',
          title: `🏆 Badge débloqué: ${badgeData.name}`,
          message: `${badgeData.description} (+${badgeData.xp} XP)`,
          priority: 'high',
          data: {
            badge_code: badgeData.code,
            badge_name: badgeData.name,
            xp_reward: badgeData.xp,
            rarity: badgeData.rarity,
            action: 'VIEW_BADGES'
          }
        });

        return {
          ...badgeData,
          id: badgeId
        };
      });
    } catch (error) {
      logger.error('Erreur lors du déblocage du badge:', error);
      throw error;
    }
  }
}

module.exports = new BadgeService();
