const { query } = require('../config/database');
const logger = require('../utils/logger');
const notificationService = require('./notification.service');

class StreakService {
  /**
   * Met à jour la série d'un utilisateur
   */
  async updateStreak(wp_user_id) {
    try {
      const query_text = `
        INSERT INTO user_streaks (
          wp_user_id,
          current_streak,
          longest_streak,
          last_active_date,
          created_at,
          updated_at
        ) VALUES ($1, 1, 1, CURRENT_DATE, NOW(), NOW())
        ON CONFLICT (wp_user_id) DO UPDATE SET
          current_streak = CASE
            WHEN user_streaks.last_active_date = CURRENT_DATE THEN user_streaks.current_streak
            WHEN user_streaks.last_active_date = CURRENT_DATE - INTERVAL '1 day' THEN user_streaks.current_streak + 1
            ELSE 1
          END,
          longest_streak = GREATEST(
            user_streaks.longest_streak,
            CASE
              WHEN user_streaks.last_active_date = CURRENT_DATE - INTERVAL '1 day' THEN user_streaks.current_streak + 1
              ELSE 1
            END
          ),
          last_active_date = CASE
            WHEN user_streaks.last_active_date != CURRENT_DATE THEN CURRENT_DATE
            ELSE user_streaks.last_active_date
          END,
          updated_at = NOW()
        RETURNING 
          wp_user_id,
          current_streak,
          longest_streak,
          last_active_date,
          CASE 
            WHEN current_streak IN (7, 30, 100) THEN current_streak
            ELSE NULL
          END AS milestone;
      `;

      const result = await query(query_text, [wp_user_id]);
      const streakData = result.rows[0];

      // Vérifier si un milestone a été atteint
      if (streakData.milestone) {
        await this.handleMilestone(streakData);
      }

      logger.info('Streak mis à jour', {
        user: wp_user_id,
        current: streakData.current_streak,
        longest: streakData.longest_streak
      });

      return {
        success: true,
        streak: streakData
      };
    } catch (error) {
      logger.error('Erreur lors de la mise à jour du streak:', error);
      throw error;
    }
  }

  /**
   * Gère les milestones de streak (7, 30, 100 jours)
   */
  async handleMilestone(streakData) {
    try {
      await notificationService.createNotification({
        wp_user_id: streakData.wp_user_id,
        notification_type: 'streak_milestone',
        title: `🔥 Série de ${streakData.milestone} jours !`,
        message: 'Incroyable régularité ! Continue comme ça !',
        priority: 'high',
        data: {
          milestone: streakData.milestone,
          current_streak: streakData.current_streak,
          longest_streak: streakData.longest_streak,
          action: 'VIEW_PROGRESS'
        }
      });

      logger.info('Milestone de streak atteint', {
        user: streakData.wp_user_id,
        milestone: streakData.milestone
      });
    } catch (error) {
      logger.error('Erreur lors du traitement du milestone:', error);
    }
  }

  /**
   * Récupère le streak actuel d'un utilisateur
   */
  async getUserStreak(wp_user_id) {
    try {
      const query_text = `
        SELECT *
        FROM user_streaks
        WHERE wp_user_id = $1;
      `;

      const result = await query(query_text, [wp_user_id]);

      if (result.rows.length === 0) {
        return {
          wp_user_id,
          current_streak: 0,
          longest_streak: 0,
          last_active_date: null
        };
      }

      return result.rows[0];
    } catch (error) {
      logger.error('Erreur lors de la récupération du streak:', error);
      throw error;
    }
  }

  /**
   * Récupère le leaderboard des streaks
   */
  async getStreakLeaderboard(limit = 10) {
    try {
      const query_text = `
        SELECT 
          us.wp_user_id,
          u.wp_display_name,
          us.current_streak,
          us.longest_streak,
          us.last_active_date
        FROM user_streaks us
        JOIN users u ON us.wp_user_id = u.wp_user_id
        ORDER BY us.current_streak DESC, us.longest_streak DESC
        LIMIT $1;
      `;

      const result = await query(query_text, [limit]);

      return {
        success: true,
        leaderboard: result.rows
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération du leaderboard:', error);
      throw error;
    }
  }

  /**
   * Vérifie les streaks expirés et envoie des notifications
   */
  async checkExpiredStreaks() {
    try {
      // Trouver les utilisateurs avec un streak > 0 qui n'ont pas été actifs aujourd'hui
      const query_text = `
        SELECT 
          us.wp_user_id,
          us.current_streak,
          u.wp_display_name,
          u.email
        FROM user_streaks us
        JOIN users u ON us.wp_user_id = u.wp_user_id
        WHERE us.current_streak > 0
          AND us.last_active_date < CURRENT_DATE - INTERVAL '1 day'
          AND NOT EXISTS (
            SELECT 1 FROM notification_queue nq
            WHERE nq.wp_user_id = us.wp_user_id
              AND nq.notification_type = 'streak_lost'
              AND nq.created_at > NOW() - INTERVAL '24 hours'
          );
      `;

      const result = await query(query_text);

      for (const user of result.rows) {
        await notificationService.createNotification({
          wp_user_id: user.wp_user_id,
          notification_type: 'streak_lost',
          title: '💔 Série perdue',
          message: `Ta série de ${user.current_streak} jours s'est terminée. Recommence dès aujourd'hui !`,
          priority: 'normal',
          data: {
            lost_streak: user.current_streak,
            action: 'START_NEW_STREAK'
          }
        });
      }

      logger.info(`Vérification des streaks expirés: ${result.rowCount} utilisateurs notifiés`);

      return {
        success: true,
        notified: result.rowCount
      };
    } catch (error) {
      logger.error('Erreur lors de la vérification des streaks expirés:', error);
      throw error;
    }
  }
}

module.exports = new StreakService();
