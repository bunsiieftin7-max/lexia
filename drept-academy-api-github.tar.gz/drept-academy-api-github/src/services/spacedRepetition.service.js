const { query } = require('../config/database');
const logger = require('../utils/logger');

class SpacedRepetitionService {
  /**
   * Met à jour les données de spaced repetition après une réponse
   * Utilise l'algorithme SM-2 (SuperMemo 2)
   */
  async updateSpacedRepetition(data) {
    const { wp_user_id, question_id, is_correct, subject_id } = data;

    try {
      // Récupérer les données actuelles
      const currentData = await this.getCurrentSRData(wp_user_id, question_id);

      // Calculer les nouvelles valeurs selon SM-2
      const newData = this.calculateSM2(currentData, is_correct);

      // Sauvegarder les nouvelles données
      const saveQuery = `
        INSERT INTO spaced_repetition (
          wp_user_id,
          question_id,
          subject_id,
          ease_factor,
          interval_days,
          repetitions,
          next_review_date,
          last_reviewed_at,
          updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
        ON CONFLICT (wp_user_id, question_id)
        DO UPDATE SET
          ease_factor = $4,
          interval_days = $5,
          repetitions = $6,
          next_review_date = $7,
          last_reviewed_at = NOW(),
          updated_at = NOW()
        RETURNING *;
      `;

      const result = await query(saveQuery, [
        wp_user_id,
        question_id,
        subject_id || 1,
        newData.ease_factor,
        newData.interval_days,
        newData.repetitions,
        newData.next_review_date
      ]);

      logger.info('Spaced repetition mis à jour', {
        user: wp_user_id,
        question: question_id,
        interval: newData.interval_days
      });

      return {
        success: true,
        data: result.rows[0],
        feedback_message: newData.feedback_message
      };
    } catch (error) {
      logger.error('Erreur lors de la mise à jour du spaced repetition:', error);
      throw error;
    }
  }

  /**
   * Récupère les données actuelles de SR pour une question
   */
  async getCurrentSRData(wp_user_id, question_id) {
    try {
      const query_text = `
        SELECT 
          COALESCE(ease_factor, 2.5) as ease_factor,
          COALESCE(interval_days, 1) as interval_days,
          COALESCE(repetitions, 0) as repetitions,
          COALESCE(next_review_date, CURRENT_DATE) as next_review_date
        FROM spaced_repetition
        WHERE wp_user_id = $1 AND question_id = $2;
      `;

      const result = await query(query_text, [wp_user_id, question_id]);

      if (result.rows.length === 0) {
        return {
          ease_factor: 2.5,
          interval_days: 1,
          repetitions: 0,
          next_review_date: new Date()
        };
      }

      return result.rows[0];
    } catch (error) {
      logger.error('Erreur lors de la récupération des données SR:', error);
      return {
        ease_factor: 2.5,
        interval_days: 1,
        repetitions: 0,
        next_review_date: new Date()
      };
    }
  }

  /**
   * Calcule les nouvelles valeurs selon l'algorithme SM-2
   */
  calculateSM2(currentData, is_correct) {
    let easeFactor = parseFloat(currentData.ease_factor) || 2.5;
    let interval = parseInt(currentData.interval_days) || 1;
    let repetitions = parseInt(currentData.repetitions) || 0;

    let feedbackMessage = '';

    if (is_correct) {
      // Réponse correcte
      if (repetitions === 0) {
        interval = 1; // Revoir demain
        feedbackMessage = `✅ Bien joué ! Je te reposerai cette question dans ${interval} jour(s).`;
      } else if (repetitions === 1) {
        interval = 6; // Revoir dans 6 jours
        feedbackMessage = `✅ Bien joué ! Je te reposerai cette question dans ${interval} jour(s).`;
      } else {
        interval = Math.round(interval * easeFactor);
        feedbackMessage = `🎯 Excellent ! Tu maîtrises cette notion. Prochaine révision dans ${interval} jours.`;
      }

      repetitions++;

      // Augmenter la facilité (max 2.5)
      easeFactor = Math.min(2.5, easeFactor + 0.1);
    } else {
      // Réponse incorrecte : RESET
      repetitions = 0;
      interval = 1; // Revoir demain

      // Diminuer la facilité (min 1.3)
      easeFactor = Math.max(1.3, easeFactor - 0.2);

      feedbackMessage = `❌ Pas tout à fait. Je te la reposerai demain pour t'aider à mémoriser.`;
    }

    // Calculer la prochaine date de révision
    const nextReview = new Date();
    nextReview.setDate(nextReview.getDate() + interval);

    return {
      ease_factor: easeFactor,
      interval_days: interval,
      repetitions: repetitions,
      next_review_date: nextReview.toISOString().split('T')[0],
      feedback_message: feedbackMessage
    };
  }

  /**
   * Récupère les questions dues pour révision
   */
  async getDueQuestions(wp_user_id, limit = 10) {
    try {
      const query_text = `
        SELECT 
          sr.*,
          s.name as subject_name
        FROM spaced_repetition sr
        LEFT JOIN subjects s ON sr.subject_id = s.id
        WHERE sr.wp_user_id = $1
          AND sr.next_review_date <= CURRENT_DATE
        ORDER BY sr.next_review_date ASC, sr.repetitions ASC
        LIMIT $2;
      `;

      const result = await query(query_text, [wp_user_id, limit]);

      return {
        success: true,
        due_questions: result.rows,
        count: result.rows.length
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération des questions dues:', error);
      throw error;
    }
  }

  /**
   * Statistiques de spaced repetition pour un utilisateur
   */
  async getSRStats(wp_user_id) {
    try {
      const query_text = `
        SELECT 
          COUNT(*) as total_cards,
          COUNT(*) FILTER (WHERE next_review_date <= CURRENT_DATE) as due_today,
          COUNT(*) FILTER (WHERE repetitions >= 3) as mastered,
          ROUND(AVG(ease_factor), 2) as avg_ease_factor,
          ROUND(AVG(interval_days), 1) as avg_interval
        FROM spaced_repetition
        WHERE wp_user_id = $1;
      `;

      const result = await query(query_text, [wp_user_id]);

      return {
        success: true,
        stats: result.rows[0]
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération des stats SR:', error);
      throw error;
    }
  }
}

module.exports = new SpacedRepetitionService();
