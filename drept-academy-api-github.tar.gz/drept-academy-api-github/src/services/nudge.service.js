const { query } = require('../config/database');
const logger = require('../utils/logger');
const notificationService = require('./notification.service');

class NudgeService {
  /**
   * Envoie des nudges intelligents selon l'heure et le contexte
   */
  async sendSmartNudges() {
    const now = new Date();
    const hour = now.getHours();

    try {
      // Récupérer les utilisateurs à nudger
      const users = await this.getUsersToNudge(hour);

      const nudgesSent = [];

      for (const user of users) {
        try {
          const nudge = await this.generateNudgeMessage(user, hour);
          
          if (nudge) {
            await notificationService.createNotification(nudge);
            nudgesSent.push(nudge);
          }
        } catch (error) {
          logger.error(`Erreur lors de la génération du nudge pour ${user.wp_user_id}:`, error);
        }
      }

      logger.info(`Nudges envoyés: ${nudgesSent.length} à ${hour}h`);

      return {
        success: true,
        nudges_sent: nudgesSent.length,
        hour
      };
    } catch (error) {
      logger.error('Erreur lors de l\'envoi des nudges:', error);
      throw error;
    }
  }

  /**
   * Récupère les utilisateurs à nudger selon l'heure
   */
  async getUsersToNudge(hour) {
    try {
      const query_text = `
        SELECT 
          u.wp_user_id,
          u.wp_display_name,
          u.email,
          us.last_activity,
          ust.current_streak,
          dp.morning_activity,
          dp.morning_completed,
          dp.afternoon_activity,
          dp.afternoon_completed,
          dp.evening_activity,
          dp.evening_completed,
          lp.enable_daily_reminder,
          EXTRACT(EPOCH FROM (NOW() - us.last_activity)) / 86400 as days_inactive
        FROM users u
        JOIN user_stats us ON u.wp_user_id = us.wp_user_id
        LEFT JOIN user_streaks ust ON u.wp_user_id = ust.wp_user_id
        LEFT JOIN daily_plans dp ON u.wp_user_id = dp.wp_user_id 
          AND dp.plan_date = CURRENT_DATE
        LEFT JOIN learning_profiles lp ON u.wp_user_id = lp.wp_user_id
        WHERE 
          (
            DATE(us.last_activity) < CURRENT_DATE
            OR ($1 = 8 AND dp.morning_activity IS NOT NULL AND dp.morning_completed = false)
            OR ($1 = 14 AND dp.afternoon_activity IS NOT NULL AND dp.afternoon_completed = false)
            OR ($1 = 20 AND dp.evening_activity IS NOT NULL AND dp.evening_completed = false)
          )
          AND (lp.enable_daily_reminder = true OR lp.enable_daily_reminder IS NULL)
          AND NOT EXISTS (
            SELECT 1 FROM notification_queue nq
            WHERE nq.wp_user_id = u.wp_user_id
              AND nq.notification_type = 'smart_nudge'
              AND nq.created_at > NOW() - INTERVAL '4 hours'
          )
        LIMIT 50;
      `;

      const result = await query(query_text, [hour]);
      return result.rows;
    } catch (error) {
      logger.error('Erreur lors de la récupération des utilisateurs à nudger:', error);
      throw error;
    }
  }

  /**
   * Génère un message de nudge personnalisé
   */
  async generateNudgeMessage(user, hour) {
    const streak = user.current_streak || 0;
    const daysInactive = Math.floor(user.days_inactive || 0);

    let title = '';
    let message = '';
    let priority = 'normal';
    let icon = '🔔';
    let action = 'OPEN_CHAT';

    // Helper pour parser JSON de manière sécurisée
    const safeParse = (json, defaultValue = {}) => {
      if (!json) return defaultValue;
      try {
        return typeof json === 'string' ? JSON.parse(json) : json;
      } catch (e) {
        return defaultValue;
      }
    };

    // Messages selon l'heure et le contexte
    if (hour === 8 && user.morning_activity && !user.morning_completed) {
      icon = '☕';
      title = `Bonjour ${user.wp_display_name || ''} !`;
      const activity = safeParse(user.morning_activity);
      message = `Commence ta journée avec ${activity.questions_count || 5} flashcards sur ${activity.subject_name || 'révision'} (${activity.duration_minutes || 5} min)`;
      action = 'START_MORNING_SESSION';
      
    } else if (hour === 14 && user.afternoon_activity && !user.afternoon_completed) {
      icon = '📚';
      title = 'Pause déjeuner ?';
      const activity = safeParse(user.afternoon_activity);
      message = `Une petite session de révision ? ${activity.duration_minutes || 5} minutes chrono !`;
      priority = 'low';
      action = 'START_AFTERNOON_SESSION';
      
    } else if (hour === 20) {
      if (user.evening_activity && !user.evening_completed) {
        icon = '🌙';
        title = 'Dernière ligne droite !';
        const activity = safeParse(user.evening_activity);
        message = `Il te reste ${activity.questions_count || 5} questions sur ${activity.subject_name || 'révision'} pour finir ta journée 🎯`;
        action = 'START_EVENING_SESSION';
      } else if (streak >= 7) {
        icon = '🔥';
        title = 'Protège ta série !';
        message = `${user.wp_display_name || ''}, ne perds pas ta série de ${streak} jours ! 10 min suffisent.`;
        priority = 'high';
        action = 'PROTECT_STREAK';
      } else {
        icon = '📖';
        title = 'Tu reviens ?';
        message = 'Le droit t\'attend ! Une session rapide avant de dormir ? 😊';
        action = 'QUICK_SESSION';
      }
      
    } else if (daysInactive > 7) {
      icon = '🎉';
      title = 'Ça fait longtemps !';
      message = `Content de te revoir ${user.wp_display_name || ''} ! J'ai préparé un quiz de remise en jambes.`;
      priority = 'high';
      action = 'COMEBACK_QUIZ';
      
    } else if (daysInactive > 3) {
      icon = '💭';
      title = 'On continue ?';
      message = 'Quelques minutes par jour font la différence ! Reviens vite 😊';
      action = 'RESUME_LEARNING';
      
    } else {
      // Pas de nudge nécessaire
      return null;
    }

    return {
      wp_user_id: user.wp_user_id,
      notification_type: 'smart_nudge',
      title: title,
      message: message,
      priority: priority,
      channel: 'in_app',
      data: {
        icon: icon,
        action: action,
        current_streak: streak,
        hour: hour,
        days_inactive: daysInactive
      }
    };
  }

  /**
   * Envoie un nudge personnalisé à un utilisateur spécifique
   */
  async sendPersonalNudge(wp_user_id, nudgeType = 'general') {
    try {
      // Récupérer les infos de l'utilisateur
      const userQuery = `
        SELECT 
          u.*,
          us.last_activity,
          ust.current_streak,
          EXTRACT(EPOCH FROM (NOW() - us.last_activity)) / 86400 as days_inactive
        FROM users u
        JOIN user_stats us ON u.wp_user_id = us.wp_user_id
        LEFT JOIN user_streaks ust ON u.wp_user_id = ust.wp_user_id
        WHERE u.wp_user_id = $1;
      `;

      const userResult = await query(userQuery, [wp_user_id]);

      if (userResult.rows.length === 0) {
        throw new Error('Utilisateur non trouvé');
      }

      const user = userResult.rows[0];
      const hour = new Date().getHours();
      
      const nudge = await this.generateNudgeMessage(user, hour);

      if (nudge) {
        await notificationService.createNotification(nudge);
        
        return {
          success: true,
          nudge
        };
      }

      return {
        success: false,
        message: 'Pas de nudge nécessaire pour le moment'
      };
    } catch (error) {
      logger.error('Erreur lors de l\'envoi du nudge personnel:', error);
      throw error;
    }
  }
}

module.exports = new NudgeService();
