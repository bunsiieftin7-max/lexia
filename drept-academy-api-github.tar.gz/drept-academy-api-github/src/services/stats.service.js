const { query, transaction } = require('../config/database');
const logger = require('../utils/logger');

class StatsService {
  /**
   * Met à jour les statistiques utilisateur après une réponse
   */
  async updateUserStats(data) {
    const { wp_user_id, is_correct, subject_id, question_id, session_id } = data;

    try {
      return await transaction(async (client) => {
        // 1. Mettre à jour les stats globales
        const statsQuery = `
          INSERT INTO user_stats (
            wp_user_id,
            total_questions_answered,
            total_correct,
            success_rate,
            total_xp,
            current_level,
            last_activity,
            updated_at
          ) VALUES ($1, 1, $2::int, CASE WHEN $2 THEN 100 ELSE 0 END, $3, 1, NOW(), NOW())
          ON CONFLICT (wp_user_id) DO UPDATE SET
            total_questions_answered = user_stats.total_questions_answered + 1,
            total_correct = user_stats.total_correct + $2::int,
            success_rate = ROUND(
              (user_stats.total_correct + $2::int) * 100.0 / 
              (user_stats.total_questions_answered + 1)
            ),
            total_xp = user_stats.total_xp + $3,
            current_level = FLOOR((user_stats.total_xp + $3) / 100) + 1,
            last_activity = NOW(),
            updated_at = NOW()
          RETURNING 
            wp_user_id,
            total_questions_answered,
            success_rate,
            total_xp,
            current_level;
        `;

        const xpGain = is_correct ? 10 : 2;
        const statsResult = await client.query(statsQuery, [
          wp_user_id,
          is_correct ? 1 : 0,
          xpGain
        ]);

        // 2. Mettre à jour les stats par sujet si subject_id est fourni
        let subjectStats = null;
        if (subject_id) {
          const subjectQuery = `
            INSERT INTO user_subject_progress (
              wp_user_id,
              subject_id,
              total_questions_answered,
              total_correct,
              success_rate,
              updated_at
            ) VALUES ($1, $2, 1, $3::int, CASE WHEN $3 THEN 100 ELSE 0 END, NOW())
            ON CONFLICT (wp_user_id, subject_id) DO UPDATE SET
              total_questions_answered = user_subject_progress.total_questions_answered + 1,
              total_correct = user_subject_progress.total_correct + $3::int,
              success_rate = ROUND(
                (user_subject_progress.total_correct + $3::int) * 100.0 / 
                (user_subject_progress.total_questions_answered + 1)
              ),
              updated_at = NOW()
            RETURNING *;
          `;

          const subjectResult = await client.query(subjectQuery, [
            wp_user_id,
            subject_id,
            is_correct ? 1 : 0
          ]);

          subjectStats = subjectResult.rows[0];
        }

        // 3. Mettre à jour ou créer la session
        const sessionQuery = `
          INSERT INTO sessions (
            wp_user_id,
            session_id,
            started_at,
            questions_answered,
            questions_correct,
            session_type
          ) VALUES ($1, $2, NOW(), 1, $3::int, $4)
          ON CONFLICT (session_id) DO UPDATE SET
            questions_answered = sessions.questions_answered + 1,
            questions_correct = sessions.questions_correct + $3::int,
            ended_at = NOW(),
            duration_minutes = EXTRACT(EPOCH FROM (NOW() - sessions.started_at))::INT / 60,
            updated_at = NOW()
          RETURNING *;
        `;

        const sessionType = data.session_type || 'MIXED';
        const sessionResult = await client.query(sessionQuery, [
          wp_user_id,
          session_id || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          is_correct ? 1 : 0,
          sessionType
        ]);

        logger.info('Stats mises à jour', {
          user: wp_user_id,
          correct: is_correct,
          xp: xpGain
        });

        return {
          success: true,
          stats: statsResult.rows[0],
          subject_stats: subjectStats,
          session: sessionResult.rows[0]
        };
      });
    } catch (error) {
      logger.error('Erreur lors de la mise à jour des stats:', error);
      throw error;
    }
  }

  /**
   * Récupère les statistiques d'un utilisateur
   */
  async getUserStats(wp_user_id) {
    try {
      const statsQuery = `
        SELECT 
          us.*,
          ust.current_streak,
          ust.longest_streak,
          ust.last_active_date,
          COUNT(DISTINCT ub.badge_id) as badges_unlocked
        FROM user_stats us
        LEFT JOIN user_streaks ust ON us.wp_user_id = ust.wp_user_id
        LEFT JOIN user_badges ub ON us.wp_user_id = ub.wp_user_id
        WHERE us.wp_user_id = $1
        GROUP BY us.wp_user_id, ust.current_streak, ust.longest_streak, ust.last_active_date;
      `;

      const result = await query(statsQuery, [wp_user_id]);

      if (result.rows.length === 0) {
        return null;
      }

      return result.rows[0];
    } catch (error) {
      logger.error('Erreur lors de la récupération des stats:', error);
      throw error;
    }
  }

  /**
   * Récupère les statistiques par sujet d'un utilisateur
   */
  async getUserSubjectStats(wp_user_id) {
    try {
      const query_text = `
        SELECT 
          usp.*,
          s.name as subject_name,
          s.description as subject_description
        FROM user_subject_progress usp
        JOIN subjects s ON usp.subject_id = s.id
        WHERE usp.wp_user_id = $1
        ORDER BY usp.total_questions_answered DESC;
      `;

      const result = await query(query_text, [wp_user_id]);
      return result.rows;
    } catch (error) {
      logger.error('Erreur lors de la récupération des stats par sujet:', error);
      throw error;
    }
  }

  /**
   * Récupère les sessions récentes d'un utilisateur
   */
  async getRecentSessions(wp_user_id, limit = 10) {
    try {
      const query_text = `
        SELECT *
        FROM sessions
        WHERE wp_user_id = $1
        ORDER BY started_at DESC
        LIMIT $2;
      `;

      const result = await query(query_text, [wp_user_id, limit]);
      return result.rows;
    } catch (error) {
      logger.error('Erreur lors de la récupération des sessions:', error);
      throw error;
    }
  }
}

module.exports = new StatsService();
