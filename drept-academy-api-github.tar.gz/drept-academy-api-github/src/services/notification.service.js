const { query } = require('../config/database');
const logger = require('../utils/logger');

class NotificationService {
  /**
   * Récupère les notifications d'un utilisateur
   */
  async getUserNotifications(wp_user_id, lastCheck = null) {
    try {
      let query_text = `
        SELECT 
          id,
          notification_type,
          title,
          message,
          priority,
          data,
          created_at,
          read_at IS NOT NULL as is_read
        FROM notification_queue
        WHERE wp_user_id = $1
      `;

      const params = [wp_user_id];

      if (lastCheck) {
        query_text += ` AND created_at > $2`;
        params.push(lastCheck);
      }

      query_text += ` ORDER BY created_at DESC LIMIT 50;`;

      const result = await query(query_text, params);

      const notifications = result.rows.map(n => {
        let parsedData = {};
        try {
          parsedData = typeof n.data === 'string' ? JSON.parse(n.data) : n.data || {};
        } catch (e) {
          logger.warn('Erreur lors du parsing de data:', e);
        }

        let icon = parsedData.icon || '🔔';
        
        // Déterminer l'icône selon le type
        if (n.notification_type === 'badge_unlocked') icon = '🏆';
        else if (n.notification_type === 'streak_milestone') icon = '🔥';
        else if (n.notification_type === 'daily_plan_ready') icon = '📅';
        else if (n.notification_type === 'smart_nudge') icon = parsedData.icon || '💡';

        return {
          id: n.id,
          title: n.title,
          message: n.message,
          icon: icon,
          timestamp: n.created_at,
          read: n.is_read,
          action: parsedData.action || 'OPEN_CHAT',
          priority: n.priority || 'normal'
        };
      });

      return {
        success: true,
        notifications,
        count: notifications.length
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération des notifications:', error);
      throw error;
    }
  }

  /**
   * Crée une nouvelle notification
   */
  async createNotification(data) {
    const {
      wp_user_id,
      notification_type,
      title,
      message,
      priority = 'normal',
      channel = 'in_app',
      data: notifData = {}
    } = data;

    try {
      const query_text = `
        INSERT INTO notification_queue (
          wp_user_id,
          notification_type,
          title,
          message,
          priority,
          channel,
          data,
          created_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
        RETURNING *;
      `;

      const result = await query(query_text, [
        wp_user_id,
        notification_type,
        title,
        message,
        priority,
        channel,
        JSON.stringify(notifData)
      ]);

      logger.info('Notification créée', {
        user: wp_user_id,
        type: notification_type
      });

      return result.rows[0];
    } catch (error) {
      logger.error('Erreur lors de la création de la notification:', error);
      throw error;
    }
  }

  /**
   * Marque une notification comme lue
   */
  async markAsRead(notificationId, wp_user_id) {
    try {
      const query_text = `
        UPDATE notification_queue
        SET read_at = NOW()
        WHERE id = $1 AND wp_user_id = $2 AND read_at IS NULL
        RETURNING *;
      `;

      const result = await query(query_text, [notificationId, wp_user_id]);

      return {
        success: result.rowCount > 0,
        notification: result.rows[0]
      };
    } catch (error) {
      logger.error('Erreur lors du marquage de la notification:', error);
      throw error;
    }
  }

  /**
   * Marque toutes les notifications comme lues
   */
  async markAllAsRead(wp_user_id) {
    try {
      const query_text = `
        UPDATE notification_queue
        SET read_at = NOW()
        WHERE wp_user_id = $1 AND read_at IS NULL
        RETURNING COUNT(*) as count;
      `;

      const result = await query(query_text, [wp_user_id]);

      return {
        success: true,
        count: result.rowCount
      };
    } catch (error) {
      logger.error('Erreur lors du marquage des notifications:', error);
      throw error;
    }
  }

  /**
   * Supprime les anciennes notifications
   */
  async cleanupOldNotifications(daysOld = 30) {
    try {
      const query_text = `
        DELETE FROM notification_queue
        WHERE created_at < NOW() - INTERVAL '${daysOld} days'
        AND read_at IS NOT NULL
        RETURNING COUNT(*) as deleted_count;
      `;

      const result = await query(query_text);

      logger.info(`Nettoyage des notifications: ${result.rowCount} supprimées`);

      return {
        success: true,
        deleted: result.rowCount
      };
    } catch (error) {
      logger.error('Erreur lors du nettoyage des notifications:', error);
      throw error;
    }
  }
}

module.exports = new NotificationService();
