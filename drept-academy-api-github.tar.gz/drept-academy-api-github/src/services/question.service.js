const { google } = require('googleapis');
const { query } = require('../config/database');
const logger = require('../utils/logger');

class QuestionService {
  constructor() {
    // Initialiser l'authentification Google Sheets
    this.auth = null;
    this.sheets = null;
    this.initializeGoogleSheets();
  }

  async initializeGoogleSheets() {
    try {
      if (!process.env.GOOGLE_CLIENT_EMAIL || !process.env.GOOGLE_PRIVATE_KEY) {
        logger.warn('Google Sheets credentials not configured');
        return;
      }

      this.auth = new google.auth.JWT(
        process.env.GOOGLE_CLIENT_EMAIL,
        null,
        process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
        ['https://www.googleapis.com/auth/spreadsheets.readonly']
      );

      this.sheets = google.sheets({ version: 'v4', auth: this.auth });
      logger.info('Google Sheets API initialisé');
    } catch (error) {
      logger.error('Erreur lors de l\'initialisation de Google Sheets:', error);
    }
  }

  /**
   * Détermine le sheet GID selon le sujet
   */
  determineSheetGid(query) {
    const queryLower = query.toLowerCase();

    // Mapping sujet → sheet GID pour flashcards
    if (queryLower.includes('penal') || queryLower.includes('pénal')) {
      if (queryLower.includes('procedur')) {
        return { gid: '1140379348', name: 'Procédure Pénale' };
      }
      return { gid: '926692406', name: 'Pénal' };
    } else if (queryLower.includes('procedur') && queryLower.includes('civil')) {
      return { gid: '595762429', name: 'Procédure Civile' };
    }

    return { gid: 'gid=0', name: 'Civil' }; // Default
  }

  /**
   * Récupère une question flashcard aléatoire depuis Google Sheets
   */
  async getRandomFlashcard(subjectQuery) {
    try {
      if (!this.sheets) {
        throw new Error('Google Sheets API non configuré');
      }

      const { gid, name } = this.determineSheetGid(subjectQuery);
      const spreadsheetId = process.env.FLASHCARD_SHEET_ID;

      // Lire toutes les données du sheet
      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId,
        range: `${gid}!A2:Z1000` // Ajuster selon vos colonnes
      });

      const rows = response.data.values || [];

      if (rows.length === 0) {
        throw new Error('Aucune question trouvée dans le sheet');
      }

      // Sélectionner une ligne aléatoire
      const randomIndex = Math.floor(Math.random() * rows.length);
      const selectedRow = rows[randomIndex];

      // Adapter selon la structure de votre sheet
      return {
        question: selectedRow[0] || '',
        answer: selectedRow[1] || '',
        explanation: selectedRow[2] || '',
        source: selectedRow[3] || '',
        subject: name
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération de la flashcard:', error);
      throw error;
    }
  }

  /**
   * Récupère une question QCM aléatoire (DB d'abord, puis Google Sheets en fallback)
   */
  async getRandomQCM(subjectQuery) {
    try {
      // D'abord essayer depuis la DB
      const subjectId = await this.getSubjectIdFromQuery(subjectQuery);
      
      const dbQuery = `
        SELECT 
          id,
          question_text,
          options,
          correct_answer,
          explanation,
          difficulty,
          tags
        FROM question_bank
        WHERE subject_id = $1 AND is_active = true
        ORDER BY RANDOM()
        LIMIT 1;
      `;

      const result = await query(dbQuery, [subjectId]);

      if (result.rows.length > 0) {
        const question = result.rows[0];
        const options = typeof question.options === 'string' 
          ? JSON.parse(question.options) 
          : question.options;

        return {
          question: question.question_text,
          option_a: options[0] || '',
          option_b: options[1] || '',
          option_c: options[2] || '',
          correct_answer: question.correct_answer,
          explanation: question.explanation,
          subject: subjectQuery,
          source: 'question_bank',
          question_id: question.id
        };
      }

      // Fallback vers Google Sheets
      return await this.getQCMFromSheets(subjectQuery, subjectId);
    } catch (error) {
      logger.error('Erreur lors de la récupération du QCM:', error);
      throw error;
    }
  }

  /**
   * Récupère un QCM depuis Google Sheets (fallback)
   */
  async getQCMFromSheets(subjectQuery, subjectId) {
    try {
      if (!this.sheets) {
        throw new Error('Google Sheets API non configuré');
      }

      const sheetGid = this.getQCMSheetGid(subjectQuery);
      const spreadsheetId = process.env.QCM_SHEET_ID;

      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId,
        range: `${sheetGid}!A2:Z1000`
      });

      const rows = response.data.values || [];

      if (rows.length === 0) {
        throw new Error('Aucune question QCM trouvée');
      }

      const randomIndex = Math.floor(Math.random() * rows.length);
      const selectedRow = rows[randomIndex];

      // Parser les choix de réponse
      const choixText = selectedRow[1] || '';
      const choix = this.parseChoixReponse(choixText);

      return {
        question: selectedRow[0] || '',
        option_a: choix.a,
        option_b: choix.b,
        option_c: choix.c,
        correct_answer: selectedRow[2] || '',
        explanation: selectedRow[3] || '',
        subject: subjectQuery,
        source: 'google_sheets',
        row_number: randomIndex + 2
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération QCM depuis Sheets:', error);
      throw error;
    }
  }

  /**
   * Parse les choix de réponse du format texte
   */
  parseChoixReponse(choixText) {
    const options = { a: '', b: '', c: '' };
    
    const aMatch = choixText.match(/A:([^\n]+)/);
    const bMatch = choixText.match(/B:([^\n]+)/);
    const cMatch = choixText.match(/C:([^\n]+)/);
    
    if (aMatch) options.a = aMatch[1].trim();
    if (bMatch) options.b = bMatch[1].trim();
    if (cMatch) options.c = cMatch[1].trim();
    
    return options;
  }

  /**
   * Détermine le sheet GID pour les QCM
   */
  getQCMSheetGid(query) {
    const queryLower = query.toLowerCase();
    
    if (queryLower.includes('procedur') && queryLower.includes('civil')) {
      return '1527930313';
    } else if (queryLower.includes('penal') || queryLower.includes('pénal')) {
      return '396414784';
    }
    
    return '906456651'; // Civil par défaut
  }

  /**
   * Récupère le subject_id depuis la query
   */
  async getSubjectIdFromQuery(queryText) {
    try {
      const query_text = `
        SELECT id, name
        FROM subjects
        WHERE 
          (LOWER($1) LIKE '%' || LOWER(name) || '%')
          OR (LOWER($1) LIKE '%civil%' AND name = 'Droit Civil')
          OR (LOWER($1) LIKE '%penal%' AND LOWER($1) NOT LIKE '%procedur%' AND name = 'Droit Pénal')
          OR (LOWER($1) LIKE '%procedur%' AND LOWER($1) LIKE '%civil%' AND name = 'Procédure Civile')
        ORDER BY id
        LIMIT 1;
      `;

      const result = await query(query_text, [queryText]);

      if (result.rows.length === 0) {
        return 1; // Droit Civil par défaut
      }

      return result.rows[0].id;
    } catch (error) {
      logger.error('Erreur lors de la récupération du subject_id:', error);
      return 1; // Default
    }
  }

  /**
   * Enregistre une réponse utilisateur
   */
  async recordUserAnswer(data) {
    const { 
      wp_user_id, 
      question_id, 
      question_type, 
      is_correct, 
      subject_id,
      time_taken 
    } = data;

    try {
      const query_text = `
        INSERT INTO user_answers (
          wp_user_id,
          question_id,
          question_type,
          is_correct,
          subject_id,
          time_taken,
          answered_at
        ) VALUES ($1, $2, $3, $4, $5, $6, NOW())
        RETURNING *;
      `;

      const result = await query(query_text, [
        wp_user_id,
        question_id,
        question_type,
        is_correct,
        subject_id,
        time_taken || null
      ]);

      return result.rows[0];
    } catch (error) {
      logger.error('Erreur lors de l\'enregistrement de la réponse:', error);
      throw error;
    }
  }
}

module.exports = new QuestionService();
