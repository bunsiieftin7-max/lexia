const express = require('express');
const router = express.Router();
const badgeService = require('../services/badge.service');
const logger = require('../utils/logger');

/**
 * POST /api/badges/get
 * Récupère les badges d'un utilisateur
 */
router.post('/get', async (req, res) => {
  try {
    const { user_id, wp_user_id } = req.body;
    const userId = user_id || wp_user_id;

    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'user_id requis',
        badges: [],
        total_badges: 0,
        unlocked_count: 0
      });
    }

    const result = await badgeService.getUserBadges(userId);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération des badges:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des badges',
      badges: [],
      total_badges: 0,
      unlocked_count: 0
    });
  }
});

/**
 * GET /api/badges/user/:userId
 * Récupère les badges d'un utilisateur (GET)
 */
router.get('/user/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const result = await badgeService.getUserBadges(wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération des badges:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des badges',
      badges: [],
      total_badges: 0,
      unlocked_count: 0
    });
  }
});

/**
 * POST /api/badges/check/:userId
 * Vérifie et débloque les badges potentiels
 */
router.post('/check/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const result = await badgeService.checkAndUnlockBadges(wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la vérification des badges:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la vérification des badges'
    });
  }
});

module.exports = router;
