const express = require('express');
const router = express.Router();
const notificationService = require('../services/notification.service');
const logger = require('../utils/logger');

/**
 * POST /api/notifications/get
 * Récupère les notifications d'un utilisateur
 */
router.post('/get', async (req, res) => {
  try {
    const { user_id, wp_user_id, last_check } = req.body;
    const userId = user_id || wp_user_id;

    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'user_id requis'
      });
    }

    const result = await notificationService.getUserNotifications(
      userId,
      last_check || new Date(Date.now() - 86400000).toISOString()
    );

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération des notifications:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des notifications',
      notifications: []
    });
  }
});

/**
 * GET /api/notifications/user/:userId
 * Récupère les notifications d'un utilisateur (GET)
 */
router.get('/user/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);
    const lastCheck = req.query.last_check;

    const result = await notificationService.getUserNotifications(wp_user_id, lastCheck);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération des notifications:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des notifications',
      notifications: []
    });
  }
});

/**
 * POST /api/notifications/create
 * Crée une nouvelle notification
 */
router.post('/create', async (req, res) => {
  try {
    const notif = await notificationService.createNotification(req.body);

    res.json({
      success: true,
      notification: notif
    });
  } catch (error) {
    logger.error('Erreur lors de la création de la notification:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la création de la notification'
    });
  }
});

/**
 * PUT /api/notifications/:id/read
 * Marque une notification comme lue
 */
router.put('/:id/read', async (req, res) => {
  try {
    const notificationId = parseInt(req.params.id);
    const { wp_user_id } = req.body;

    if (!wp_user_id) {
      return res.status(400).json({
        success: false,
        error: 'wp_user_id requis'
      });
    }

    const result = await notificationService.markAsRead(notificationId, wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors du marquage de la notification:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors du marquage de la notification'
    });
  }
});

/**
 * PUT /api/notifications/user/:userId/read-all
 * Marque toutes les notifications comme lues
 */
router.put('/user/:userId/read-all', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const result = await notificationService.markAllAsRead(wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors du marquage des notifications:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors du marquage des notifications'
    });
  }
});

module.exports = router;
