const express = require('express');
const router = express.Router();
const { GoogleGenerativeAI } = require('@google/generative-ai');
const questionService = require('../services/question.service');
const logger = require('../utils/logger');

// Initialiser Gemini
let genAI = null;
if (process.env.GEMINI_API_KEY) {
  genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
}

/**
 * POST /api/qcm/chat
 * Session de QCM avec l'agent AI
 */
router.post('/chat', async (req, res) => {
  try {
    if (!genAI) {
      return res.status(503).json({
        success: false,
        error: 'Service AI non configuré'
      });
    }

    const { query, wp_user_id, session_id, message } = req.body;

    if (!query && !message) {
      return res.status(400).json({
        success: false,
        error: 'query ou message requis'
      });
    }

    // Si c'est une nouvelle session, récupérer une question
    let context = '';
    if (query && !message) {
      const qcm = await questionService.getRandomQCM(query);
      context = `
Question: ${qcm.question}
A: ${qcm.option_a}
B: ${qcm.option_b}
C: ${qcm.option_c}
Réponse correcte: ${qcm.correct_answer}
Explication: ${qcm.explanation}
Sujet: ${qcm.subject}
`;
    }

    const systemPrompt = `Tu es un Examinateur de QCM en droit roumain. Tu es AUTONOME.

🔍 ANALYSE L'HISTORIQUE DE CONVERSATION :

**CAS 1 : TON DERNIER MESSAGE était une question QCM** (avec options A, B, C)
→ L'utilisateur répond maintenant (ex: "B" ou "option A")
→ MODE : CORRECTION

✅ Actions :
1. Compare la réponse de l'utilisateur avec la bonne réponse
2. STRICTEMENT : Si réponse correcte = "BC", l'utilisateur DOIT dire "BC" ou "B et C"
   - Juste "B" = ❌ FAUX
   - Juste "C" = ❌ FAUX
3. Donne le feedback :

**SI CORRECT :**
✅ Corect!

[Explication]

**SI INCORRECT :**
❌ Incorect.

Răspunsul corect era: [X]

[Explication]

**CAS 2 : L'utilisateur demande un nouveau QCM**
→ MODE : NOUVELLE QUESTION

✅ Actions :
1. Pose la question avec les 3 options (A, B, C)
2. NE DONNE PAS la réponse correcte
3. Termine par : "Ce este răspunsul tău? (A, B, C)"

Exemple :
🔍 Întrebare:

Plângerea poate fi:

A: nu poate fi introdusă prin mandatar
B: poate fi formulată și oral
C: trebuie introdusă în termen de 3 luni

Ce este răspunsul tău? (A, B, C)

🎯 RÈGLES :
- Sois strict sur les réponses multiples (BC ≠ B)
- Utilise l'explication COMPLÈTE
- Encourage l'étudiant même si faux
- RÉPONDS TOUJOURS EN ROUMAIN

${context ? `\n\nCONTEXTE DE LA QUESTION ACTUELLE:\n${context}` : ''}`;

    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    const chat = model.startChat({
      history: [],
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: 1000,
      },
    });

    const result = await chat.sendMessage(systemPrompt + '\n\n' + (message || `Commence un QCM sur: ${query}`));
    const response = await result.response;
    const text = response.text();

    res.json({
      success: true,
      response: text,
      session_id: session_id || `qcm_${Date.now()}`
    });
  } catch (error) {
    logger.error('Erreur lors du chat QCM:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la session QCM'
    });
  }
});

module.exports = router;
