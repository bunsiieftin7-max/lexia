const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const logger = require('../utils/logger');

/**
 * GET /api/health
 * Health check simple
 */
router.get('/', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV
  });
});

/**
 * GET /api/health/detailed
 * Health check détaillé avec statut de la base de données
 */
router.get('/detailed', async (req, res) => {
  try {
    // Test de connexion à la base de données
    const dbStart = Date.now();
    await query('SELECT NOW()');
    const dbLatency = Date.now() - dbStart;

    // Vérifier l'utilisation de la mémoire
    const memUsage = process.memoryUsage();

    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV,
      database: {
        status: 'connected',
        latency_ms: dbLatency
      },
      memory: {
        rss_mb: Math.round(memUsage.rss / 1024 / 1024),
        heap_used_mb: Math.round(memUsage.heapUsed / 1024 / 1024),
        heap_total_mb: Math.round(memUsage.heapTotal / 1024 / 1024)
      },
      services: {
        gemini_ai: !!process.env.GEMINI_API_KEY,
        google_sheets: !!(process.env.GOOGLE_CLIENT_EMAIL && process.env.GOOGLE_PRIVATE_KEY),
        cron_jobs: process.env.ENABLE_CRON_JOBS === 'true'
      }
    });
  } catch (error) {
    logger.error('Erreur lors du health check:', error);
    res.status(503).json({
      status: 'error',
      timestamp: new Date().toISOString(),
      error: 'Service unavailable',
      database: {
        status: 'disconnected'
      }
    });
  }
});

/**
 * GET /api/health/database
 * Test de connexion à la base de données uniquement
 */
router.get('/database', async (req, res) => {
  try {
    const start = Date.now();
    const result = await query('SELECT COUNT(*) as user_count FROM users');
    const latency = Date.now() - start;

    res.json({
      status: 'ok',
      database: 'connected',
      latency_ms: latency,
      user_count: result.rows[0].user_count
    });
  } catch (error) {
    logger.error('Erreur lors du test de la base de données:', error);
    res.status(503).json({
      status: 'error',
      database: 'disconnected',
      error: error.message
    });
  }
});

module.exports = router;
