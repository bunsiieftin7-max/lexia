const express = require('express');
const router = express.Router();
const plannerService = require('../services/planner.service');
const logger = require('../utils/logger');

/**
 * GET /api/planner/today/:userId
 * Récupère le plan du jour d'un utilisateur
 */
router.get('/today/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const result = await plannerService.getTodayPlan(wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération du plan:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération du plan du jour'
    });
  }
});

/**
 * POST /api/planner/generate/:userId
 * Génère un plan pour un utilisateur spécifique
 */
router.post('/generate/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    // Récupérer les infos utilisateur
    const { query } = require('../config/database');
    const userQuery = `
      SELECT 
        u.wp_user_id,
        u.wp_display_name,
        u.email,
        us.last_activity,
        ust.current_streak,
        lp.preferred_time,
        lp.preferred_duration_minutes,
        lp.enable_daily_reminder
      FROM users u
      JOIN user_stats us ON u.wp_user_id = us.wp_user_id
      LEFT JOIN user_streaks ust ON u.wp_user_id = ust.wp_user_id
      LEFT JOIN learning_profiles lp ON u.wp_user_id = lp.wp_user_id
      WHERE u.wp_user_id = $1;
    `;

    const userResult = await query(userQuery, [wp_user_id]);

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Utilisateur non trouvé'
      });
    }

    const plan = await plannerService.generatePlanForUser(userResult.rows[0]);

    res.json({
      success: true,
      plan
    });
  } catch (error) {
    logger.error('Erreur lors de la génération du plan:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la génération du plan'
    });
  }
});

/**
 * POST /api/planner/complete/:userId/:activityType
 * Marque une activité comme complétée
 */
router.post('/complete/:userId/:activityType', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);
    const activityType = req.params.activityType;

    const result = await plannerService.markActivityCompleted(wp_user_id, activityType);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors du marquage de l\'activité:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors du marquage de l\'activité'
    });
  }
});

/**
 * GET /api/planner/stats/:userId
 * Récupère les statistiques de complétion des plans
 */
router.get('/stats/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);
    const days = parseInt(req.query.days) || 7;

    const result = await plannerService.getPlanStats(wp_user_id, days);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération des stats:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des statistiques'
    });
  }
});

module.exports = router;
