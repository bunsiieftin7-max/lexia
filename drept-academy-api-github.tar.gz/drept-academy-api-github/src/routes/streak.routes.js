const express = require('express');
const router = express.Router();
const streakService = require('../services/streak.service');
const logger = require('../utils/logger');

/**
 * GET /api/streak/user/:userId
 * Récupère le streak d'un utilisateur
 */
router.get('/user/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const streak = await streakService.getUserStreak(wp_user_id);

    res.json({
      success: true,
      streak
    });
  } catch (error) {
    logger.error('Erreur lors de la récupération du streak:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération du streak'
    });
  }
});

/**
 * POST /api/streak/update/:userId
 * Met à jour le streak d'un utilisateur
 */
router.post('/update/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const result = await streakService.updateStreak(wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la mise à jour du streak:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la mise à jour du streak'
    });
  }
});

/**
 * GET /api/streak/leaderboard
 * Récupère le leaderboard des streaks
 */
router.get('/leaderboard', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;

    const result = await streakService.getStreakLeaderboard(limit);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération du leaderboard:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération du leaderboard'
    });
  }
});

module.exports = router;
