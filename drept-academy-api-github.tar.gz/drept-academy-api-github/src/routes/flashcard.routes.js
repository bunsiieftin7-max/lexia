const express = require('express');
const router = express.Router();
const { GoogleGenerativeAI } = require('@google/generative-ai');
const questionService = require('../services/question.service');
const logger = require('../utils/logger');

// Initialiser Gemini
let genAI = null;
if (process.env.GEMINI_API_KEY) {
  genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
}

/**
 * POST /api/flashcard/chat
 * Session de flashcard avec l'agent AI
 */
router.post('/chat', async (req, res) => {
  try {
    if (!genAI) {
      return res.status(503).json({
        success: false,
        error: 'Service AI non configuré'
      });
    }

    const { query, wp_user_id, session_id, message } = req.body;

    if (!query && !message) {
      return res.status(400).json({
        success: false,
        error: 'query ou message requis'
      });
    }

    // Si c'est une nouvelle session, récupérer une question
    let context = '';
    if (query && !message) {
      const flashcard = await questionService.getRandomFlashcard(query);
      context = `
Question: ${flashcard.question}
Réponse correcte: ${flashcard.answer}
Explication: ${flashcard.explanation}
Source: ${flashcard.source}
Sujet: ${flashcard.subject}
`;
    }

    const systemPrompt = `Tu es un Examinateur de Droit rigoureux. Tu es AUTONOME.

🔍 ANALYSE L'HISTORIQUE DE CONVERSATION :

**CAS 1 : TON DERNIER MESSAGE était une question ouverte**
→ L'utilisateur répond maintenant
→ MODE : CORRECTION

✅ Actions :
1. Analyse sa réponse
2. Compare avec la bonne réponse que tu connais
3. Donne le feedback :

✅ Corect! / ❌ Incorect.

[Explication juridique avec source : Art. XXX Code ...]

Nota: [X]/10

➡️ Întrebare următoare...

4. Pose IMMÉDIATEMENT la question suivante (max 5 questions par session)

**CAS 2 : Nouvelle demande de révision / flashcard**
→ MODE : NOUVELLE SESSION

✅ Actions :
1. Identifie le sujet demandé
2. Pose SEULEMENT la Question n°1
3. Termine par : "Aștept răspunsul tău. 💭"

# RÈGLES IMPORTANTES :

- Une question à la fois
- Attends TOUJOURS la réponse avant de corriger
- Sois tolérant : accepte les réponses bien formulées même si différentes
- Cite les sources juridiques (Art. XXX)
- Encourage l'étudiant
- Après 5 questions : bilan rapide

${context ? `\n\nCONTEXTE DE LA QUESTION ACTUELLE:\n${context}` : ''}

RÉPONDS TOUJOURS EN ROUMAIN.`;

    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    const chat = model.startChat({
      history: [],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 1000,
      },
    });

    const result = await chat.sendMessage(systemPrompt + '\n\n' + (message || `Commence une session sur: ${query}`));
    const response = await result.response;
    const text = response.text();

    res.json({
      success: true,
      response: text,
      session_id: session_id || `flashcard_${Date.now()}`
    });
  } catch (error) {
    logger.error('Erreur lors du chat flashcard:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la session flashcard'
    });
  }
});

module.exports = router;
