const express = require('express');
const router = express.Router();
const statsService = require('../services/stats.service');
const streakService = require('../services/streak.service');
const badgeService = require('../services/badge.service');
const logger = require('../utils/logger');

/**
 * POST /api/stats/update
 * Met à jour les statistiques après une réponse
 */
router.post('/update', async (req, res) => {
  try {
    const { wp_user_id, is_correct, subject_id, question_id, session_id, session_type } = req.body;

    if (!wp_user_id || is_correct === undefined) {
      return res.status(400).json({
        success: false,
        error: 'wp_user_id et is_correct sont requis'
      });
    }

    // Mettre à jour les stats
    const result = await statsService.updateUserStats({
      wp_user_id,
      is_correct,
      subject_id,
      question_id: question_id || `q_${Date.now()}`,
      session_id: session_id || `session_${Date.now()}`,
      session_type
    });

    // Mettre à jour le streak
    await streakService.updateStreak(wp_user_id);

    // Vérifier les badges
    await badgeService.checkAndUnlockBadges(wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la mise à jour des stats:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la mise à jour des statistiques'
    });
  }
});

/**
 * GET /api/stats/user/:userId
 * Récupère les statistiques d'un utilisateur
 */
router.get('/user/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    if (!wp_user_id) {
      return res.status(400).json({
        success: false,
        error: 'userId invalide'
      });
    }

    const stats = await statsService.getUserStats(wp_user_id);

    if (!stats) {
      return res.status(404).json({
        success: false,
        error: 'Utilisateur non trouvé'
      });
    }

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    logger.error('Erreur lors de la récupération des stats:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des statistiques'
    });
  }
});

/**
 * GET /api/stats/user/:userId/subjects
 * Récupère les statistiques par sujet d'un utilisateur
 */
router.get('/user/:userId/subjects', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const subjectStats = await statsService.getUserSubjectStats(wp_user_id);

    res.json({
      success: true,
      subjects: subjectStats
    });
  } catch (error) {
    logger.error('Erreur lors de la récupération des stats par sujet:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des statistiques par sujet'
    });
  }
});

/**
 * GET /api/stats/user/:userId/sessions
 * Récupère les sessions récentes d'un utilisateur
 */
router.get('/user/:userId/sessions', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);
    const limit = parseInt(req.query.limit) || 10;

    const sessions = await statsService.getRecentSessions(wp_user_id, limit);

    res.json({
      success: true,
      sessions
    });
  } catch (error) {
    logger.error('Erreur lors de la récupération des sessions:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des sessions'
    });
  }
});

module.exports = router;
