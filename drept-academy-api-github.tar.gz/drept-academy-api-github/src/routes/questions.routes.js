const express = require('express');
const router = express.Router();
const questionService = require('../services/question.service');
const spacedRepetitionService = require('../services/spacedRepetition.service');
const logger = require('../utils/logger');

/**
 * POST /api/questions/flashcard
 * Récupère une question flashcard aléatoire
 */
router.post('/flashcard', async (req, res) => {
  try {
    const { query: subjectQuery } = req.body;

    if (!subjectQuery) {
      return res.status(400).json({
        success: false,
        error: 'query requis'
      });
    }

    const flashcard = await questionService.getRandomFlashcard(subjectQuery);

    res.json({
      success: true,
      flashcard
    });
  } catch (error) {
    logger.error('Erreur lors de la récupération de la flashcard:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération de la flashcard'
    });
  }
});

/**
 * POST /api/questions/qcm
 * Récupère une question QCM aléatoire
 */
router.post('/qcm', async (req, res) => {
  try {
    const { query: subjectQuery } = req.body;

    if (!subjectQuery) {
      return res.status(400).json({
        success: false,
        error: 'query requis'
      });
    }

    const qcm = await questionService.getRandomQCM(subjectQuery);

    res.json({
      success: true,
      qcm
    });
  } catch (error) {
    logger.error('Erreur lors de la récupération du QCM:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération du QCM'
    });
  }
});

/**
 * POST /api/questions/answer
 * Enregistre une réponse utilisateur
 */
router.post('/answer', async (req, res) => {
  try {
    const {
      wp_user_id,
      question_id,
      question_type,
      is_correct,
      subject_id,
      time_taken
    } = req.body;

    if (!wp_user_id || !question_id || question_type === undefined) {
      return res.status(400).json({
        success: false,
        error: 'Paramètres manquants'
      });
    }

    // Enregistrer la réponse
    const answer = await questionService.recordUserAnswer(req.body);

    // Mettre à jour le spaced repetition si applicable
    let srResult = null;
    if (question_type === 'flashcard' || question_type === 'qcm') {
      srResult = await spacedRepetitionService.updateSpacedRepetition({
        wp_user_id,
        question_id,
        is_correct,
        subject_id
      });
    }

    res.json({
      success: true,
      answer,
      spaced_repetition: srResult
    });
  } catch (error) {
    logger.error('Erreur lors de l\'enregistrement de la réponse:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de l\'enregistrement de la réponse'
    });
  }
});

/**
 * GET /api/questions/due/:userId
 * Récupère les questions dues pour révision
 */
router.get('/due/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);
    const limit = parseInt(req.query.limit) || 10;

    const result = await spacedRepetitionService.getDueQuestions(wp_user_id, limit);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération des questions dues:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des questions dues'
    });
  }
});

/**
 * GET /api/questions/sr-stats/:userId
 * Récupère les statistiques de spaced repetition
 */
router.get('/sr-stats/:userId', async (req, res) => {
  try {
    const wp_user_id = parseInt(req.params.userId);

    const result = await spacedRepetitionService.getSRStats(wp_user_id);

    res.json(result);
  } catch (error) {
    logger.error('Erreur lors de la récupération des stats SR:', error);
    res.status(500).json({
      success: false,
      error: 'Erreur lors de la récupération des statistiques'
    });
  }
});

module.exports = router;
