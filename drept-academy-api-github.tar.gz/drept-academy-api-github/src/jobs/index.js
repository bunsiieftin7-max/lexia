const cron = require('node-cron');
const logger = require('../utils/logger');
const plannerService = require('../services/planner.service');
const nudgeService = require('../services/nudge.service');
const badgeService = require('../services/badge.service');
const streakService = require('../services/streak.service');
const notificationService = require('../services/notification.service');

let jobs = [];

/**
 * Démarre tous les jobs planifiés
 */
function startCronJobs() {
  logger.info('🕐 Démarrage des jobs planifiés...');

  // Job 1: Daily Learning Planner - Tous les jours à 6h du matin
  const dailyPlannerJob = cron.schedule(
    process.env.DAILY_PLANNER_CRON || '0 6 * * *',
    async () => {
      logger.info('📅 Exécution du Daily Learning Planner');
      try {
        await plannerService.generateDailyPlans();
        logger.info('✅ Daily Learning Planner terminé');
      } catch (error) {
        logger.error('❌ Erreur dans Daily Learning Planner:', error);
      }
    },
    {
      timezone: 'Europe/Bucharest'
    }
  );

  jobs.push({ name: 'Daily Learning Planner', job: dailyPlannerJob });

  // Job 2: Smart Nudges - À 8h, 14h et 20h
  const smartNudgeJob = cron.schedule(
    process.env.SMART_NUDGE_CRON || '0 8,14,20 * * *',
    async () => {
      logger.info('💡 Exécution du Smart Nudge System');
      try {
        await nudgeService.sendSmartNudges();
        logger.info('✅ Smart Nudge System terminé');
      } catch (error) {
        logger.error('❌ Erreur dans Smart Nudge System:', error);
      }
    },
    {
      timezone: 'Europe/Bucharest'
    }
  );

  jobs.push({ name: 'Smart Nudge System', job: smartNudgeJob });

  // Job 3: Badge Checker - Toutes les heures
  const badgeCheckerJob = cron.schedule(
    process.env.BADGE_CHECK_CRON || '0 * * * *',
    async () => {
      logger.info('🏆 Exécution du Badge Checker');
      try {
        // Vérifier les badges pour les utilisateurs actifs récemment
        const { query } = require('./config/database');
        const activeUsers = await query(`
          SELECT DISTINCT wp_user_id 
          FROM user_stats 
          WHERE last_activity > NOW() - INTERVAL '1 hour'
        `);

        for (const user of activeUsers.rows) {
          try {
            await badgeService.checkAndUnlockBadges(user.wp_user_id);
          } catch (error) {
            logger.error(`Erreur badge pour user ${user.wp_user_id}:`, error);
          }
        }

        logger.info('✅ Badge Checker terminé');
      } catch (error) {
        logger.error('❌ Erreur dans Badge Checker:', error);
      }
    },
    {
      timezone: 'Europe/Bucharest'
    }
  );

  jobs.push({ name: 'Badge Checker', job: badgeCheckerJob });

  // Job 4: Streak Checker - Tous les jours à minuit
  const streakCheckerJob = cron.schedule(
    '0 0 * * *',
    async () => {
      logger.info('🔥 Exécution du Streak Checker');
      try {
        await streakService.checkExpiredStreaks();
        logger.info('✅ Streak Checker terminé');
      } catch (error) {
        logger.error('❌ Erreur dans Streak Checker:', error);
      }
    },
    {
      timezone: 'Europe/Bucharest'
    }
  );

  jobs.push({ name: 'Streak Checker', job: streakCheckerJob });

  // Job 5: Notification Cleanup - Tous les dimanches à 3h du matin
  const notifCleanupJob = cron.schedule(
    '0 3 * * 0',
    async () => {
      logger.info('🧹 Exécution du Notification Cleanup');
      try {
        await notificationService.cleanupOldNotifications(30);
        logger.info('✅ Notification Cleanup terminé');
      } catch (error) {
        logger.error('❌ Erreur dans Notification Cleanup:', error);
      }
    },
    {
      timezone: 'Europe/Bucharest'
    }
  );

  jobs.push({ name: 'Notification Cleanup', job: notifCleanupJob });

  logger.info(`✅ ${jobs.length} jobs planifiés démarrés`);
}

/**
 * Arrête tous les jobs planifiés
 */
function stopCronJobs() {
  logger.info('Arrêt des jobs planifiés...');
  jobs.forEach(({ name, job }) => {
    job.stop();
    logger.info(`Arrêt de: ${name}`);
  });
  jobs = [];
}

/**
 * Récupère le statut de tous les jobs
 */
function getJobsStatus() {
  return jobs.map(({ name, job }) => ({
    name,
    running: job.running || false
  }));
}

module.exports = {
  startCronJobs,
  stopCronJobs,
  getJobsStatus
};
