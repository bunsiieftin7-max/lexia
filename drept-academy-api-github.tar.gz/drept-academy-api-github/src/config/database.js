const { Pool } = require('pg');
const logger = require('../utils/logger');

// Configuration de la pool PostgreSQL
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DB_SSL === 'true' ? {
    rejectUnauthorized: false
  } : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

// Event handlers
pool.on('connect', () => {
  logger.debug('Nouvelle connexion PostgreSQL établie');
});

pool.on('error', (err) => {
  logger.error('Erreur PostgreSQL inattendue:', err);
});

// Test connection function
async function initializeDatabase() {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT NOW()');
    logger.info('Connexion PostgreSQL réussie:', result.rows[0].now);
    client.release();
    return true;
  } catch (error) {
    logger.error('Erreur de connexion PostgreSQL:', error);
    throw error;
  }
}

// Query helper with error handling
async function query(text, params) {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;
    
    logger.debug('Query exécutée', {
      text: text.substring(0, 100),
      duration: `${duration}ms`,
      rows: result.rowCount
    });
    
    return result;
  } catch (error) {
    logger.error('Erreur de query:', {
      error: error.message,
      query: text.substring(0, 100),
      params
    });
    throw error;
  }
}

// Transaction helper
async function transaction(callback) {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    logger.error('Transaction rollback:', error);
    throw error;
  } finally {
    client.release();
  }
}

// Graceful shutdown
async function closeDatabase() {
  try {
    await pool.end();
    logger.info('Pool PostgreSQL fermé');
  } catch (error) {
    logger.error('Erreur lors de la fermeture du pool:', error);
    throw error;
  }
}

module.exports = {
  pool,
  query,
  transaction,
  initializeDatabase,
  closeDatabase
};
