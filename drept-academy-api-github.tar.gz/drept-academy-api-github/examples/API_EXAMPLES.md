# 📡 Exemples de Requêtes API

Collection de requêtes pour tester l'API Drept Academy.

## 🔧 Configuration

Base URL : `https://your-app.onrender.com/api`

Pour les tests locaux : `http://localhost:3000/api`

## 🏥 Health Checks

### Health Check Simple
```bash
curl https://your-app.onrender.com/api/health
```

### Health Check Détaillé
```bash
curl https://your-app.onrender.com/api/health/detailed | jq
```

### Database Status
```bash
curl https://your-app.onrender.com/api/health/database | jq
```

## 📊 Statistiques

### Mettre à Jour les Stats
```bash
curl -X POST https://your-app.onrender.com/api/stats/update \
  -H "Content-Type: application/json" \
  -d '{
    "wp_user_id": 1,
    "is_correct": true,
    "subject_id": 1,
    "question_id": "q_12345",
    "session_id": "session_abc123"
  }' | jq
```

### Récupérer Stats Utilisateur
```bash
curl https://your-app.onrender.com/api/stats/user/1 | jq
```

### Stats par Sujet
```bash
curl https://your-app.onrender.com/api/stats/user/1/subjects | jq
```

### Sessions Récentes
```bash
curl https://your-app.onrender.com/api/stats/user/1/sessions?limit=5 | jq
```

## 🏆 Badges

### Récupérer Tous les Badges
```bash
curl -X POST https://your-app.onrender.com/api/badges/get \
  -H "Content-Type: application/json" \
  -d '{"user_id": 1}' | jq
```

### Alternative GET
```bash
curl https://your-app.onrender.com/api/badges/user/1 | jq
```

### Vérifier et Débloquer Badges
```bash
curl -X POST https://your-app.onrender.com/api/badges/check/1 | jq
```

## 🔥 Streaks

### Récupérer Streak Utilisateur
```bash
curl https://your-app.onrender.com/api/streak/user/1 | jq
```

### Mettre à Jour Streak
```bash
curl -X POST https://your-app.onrender.com/api/streak/update/1 | jq
```

### Leaderboard des Streaks
```bash
curl https://your-app.onrender.com/api/streak/leaderboard?limit=10 | jq
```

## 🔔 Notifications

### Récupérer Notifications
```bash
curl -X POST https://your-app.onrender.com/api/notifications/get \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": 1,
    "last_check": "2024-01-01T00:00:00Z"
  }' | jq
```

### Alternative GET
```bash
curl https://your-app.onrender.com/api/notifications/user/1 | jq
```

### Marquer comme Lue
```bash
curl -X PUT https://your-app.onrender.com/api/notifications/123/read \
  -H "Content-Type: application/json" \
  -d '{"wp_user_id": 1}' | jq
```

### Tout Marquer comme Lu
```bash
curl -X PUT https://your-app.onrender.com/api/notifications/user/1/read-all | jq
```

## 🎴 Questions

### Obtenir une Flashcard
```bash
curl -X POST https://your-app.onrender.com/api/questions/flashcard \
  -H "Content-Type: application/json" \
  -d '{"query": "droit civil"}' | jq
```

### Obtenir un QCM
```bash
curl -X POST https://your-app.onrender.com/api/questions/qcm \
  -H "Content-Type: application/json" \
  -d '{"query": "droit pénal"}' | jq
```

### Enregistrer une Réponse
```bash
curl -X POST https://your-app.onrender.com/api/questions/answer \
  -H "Content-Type: application/json" \
  -d '{
    "wp_user_id": 1,
    "question_id": "q_12345",
    "question_type": "qcm",
    "is_correct": true,
    "subject_id": 1,
    "time_taken": 45
  }' | jq
```

### Questions Dues pour Révision
```bash
curl https://your-app.onrender.com/api/questions/due/1?limit=10 | jq
```

### Stats Spaced Repetition
```bash
curl https://your-app.onrender.com/api/questions/sr-stats/1 | jq
```

## 🤖 IA Conversationnelle

### Session Flashcard AI
```bash
curl -X POST https://your-app.onrender.com/api/flashcard/chat \
  -H "Content-Type: application/json" \
  -d '{
    "query": "droit civil",
    "wp_user_id": 1,
    "session_id": "flashcard_session_123"
  }' | jq
```

### Répondre dans une Session
```bash
curl -X POST https://your-app.onrender.com/api/flashcard/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Le droit de propriété est...",
    "wp_user_id": 1,
    "session_id": "flashcard_session_123"
  }' | jq
```

### Session QCM AI
```bash
curl -X POST https://your-app.onrender.com/api/qcm/chat \
  -H "Content-Type: application/json" \
  -d '{
    "query": "droit pénal",
    "wp_user_id": 1,
    "session_id": "qcm_session_456"
  }' | jq
```

### Répondre dans un QCM
```bash
curl -X POST https://your-app.onrender.com/api/qcm/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "B",
    "wp_user_id": 1,
    "session_id": "qcm_session_456"
  }' | jq
```

## 📅 Planificateur

### Récupérer le Plan du Jour
```bash
curl https://your-app.onrender.com/api/planner/today/1 | jq
```

### Générer un Plan
```bash
curl -X POST https://your-app.onrender.com/api/planner/generate/1 | jq
```

### Marquer Activité Complétée
```bash
# morning, afternoon, ou evening
curl -X POST https://your-app.onrender.com/api/planner/complete/1/morning | jq
```

### Stats de Complétion
```bash
curl https://your-app.onrender.com/api/planner/stats/1?days=7 | jq
```

## 🗄️ Commandes PostgreSQL

### Se Connecter
```bash
psql $DATABASE_URL
```

### Créer un Utilisateur Test
```sql
INSERT INTO users (wp_user_id, wp_display_name, email) 
VALUES (1, 'Test User', 'test@example.com');
```

### Voir les Stats
```sql
SELECT * FROM v_user_complete_stats WHERE wp_user_id = 1;
```

### Voir les Notifications
```sql
SELECT * FROM notification_queue 
WHERE wp_user_id = 1 
ORDER BY created_at DESC 
LIMIT 10;
```

### Voir les Badges Débloqués
```sql
SELECT b.name, b.icon_emoji, ub.unlocked_at
FROM user_badges ub
JOIN badges b ON ub.badge_id = b.id
WHERE ub.wp_user_id = 1
ORDER BY ub.unlocked_at DESC;
```

## 📝 Tests Complets (Scénario)

### 1. Créer un Utilisateur
```bash
psql $DATABASE_URL -c "INSERT INTO users (wp_user_id, wp_display_name, email) VALUES (1, 'John Doe', 'john@example.com');"
```

### 2. Répondre à 10 Questions
```bash
for i in {1..10}; do
  curl -X POST https://your-app.onrender.com/api/stats/update \
    -H "Content-Type: application/json" \
    -d "{
      \"wp_user_id\": 1,
      \"is_correct\": true,
      \"subject_id\": 1,
      \"question_id\": \"q_$i\"
    }"
  sleep 1
done
```

### 3. Vérifier les Badges
```bash
curl -X POST https://your-app.onrender.com/api/badges/check/1 | jq
```

### 4. Voir les Stats
```bash
curl https://your-app.onrender.com/api/stats/user/1 | jq
```

### 5. Voir les Notifications
```bash
curl https://your-app.onrender.com/api/notifications/user/1 | jq
```

## 🔍 Debugging

### Vérifier la Configuration
```bash
curl https://your-app.onrender.com/api/health/detailed | jq '.services'
```

### Tester la DB
```bash
curl https://your-app.onrender.com/api/health/database | jq
```

### Voir les Logs (sur Render)
```bash
# Render Dashboard → Votre Service → Logs
```

## 📦 Export Postman

Pour importer dans Postman :
1. Créez une nouvelle collection
2. Ajoutez une variable `{{baseUrl}}` avec la valeur `https://your-app.onrender.com/api`
3. Importez les requêtes ci-dessus

## 🎯 Tips

### Utiliser jq pour filtrer
```bash
# Voir seulement le succès
curl ... | jq '.success'

# Voir seulement les badges débloqués
curl ... | jq '.badges[] | select(.is_unlocked == true)'

# Compter les notifications non lues
curl ... | jq '[.notifications[] | select(.read == false)] | length'
```

### Variables d'environnement
```bash
export API_URL="https://your-app.onrender.com/api"
export USER_ID=1

curl $API_URL/stats/user/$USER_ID | jq
```

---

💡 **Astuce** : Utilisez Postman, Insomnia, ou Thunder Client pour une meilleure expérience de test !
