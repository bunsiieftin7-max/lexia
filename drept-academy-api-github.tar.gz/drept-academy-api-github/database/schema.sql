-- ============================================
-- DREPT ACADEMY - DATABASE SCHEMA
-- PostgreSQL Schema for Learning Platform
-- ============================================

-- Drop tables if exists (for clean install)
DROP TABLE IF EXISTS user_answers CASCADE;
DROP TABLE IF EXISTS spaced_repetition CASCADE;
DROP TABLE IF EXISTS daily_plans CASCADE;
DROP TABLE IF EXISTS notification_queue CASCADE;
DROP TABLE IF EXISTS user_badges CASCADE;
DROP TABLE IF EXISTS badges CASCADE;
DROP TABLE IF EXISTS sessions CASCADE;
DROP TABLE IF EXISTS user_streaks CASCADE;
DROP TABLE IF EXISTS user_subject_progress CASCADE;
DROP TABLE IF EXISTS user_stats CASCADE;
DROP TABLE IF EXISTS question_bank CASCADE;
DROP TABLE IF EXISTS subjects CASCADE;
DROP TABLE IF EXISTS learning_profiles CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS system_logs CASCADE;

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
    wp_user_id INTEGER PRIMARY KEY,
    wp_display_name VARCHAR(255),
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);

-- ============================================
-- SUBJECTS TABLE
-- ============================================
CREATE TABLE subjects (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Insert default subjects
INSERT INTO subjects (name, description) VALUES
    ('Droit Civil', 'Droit civil général'),
    ('Droit Pénal', 'Droit pénal général'),
    ('Procédure Civile', 'Procédure civile et contentieux'),
    ('Procédure Pénale', 'Procédure pénale'),
    ('Droit Constitutionnel', 'Droit constitutionnel et institutions'),
    ('Droit Administratif', 'Droit administratif général');

-- ============================================
-- USER STATS TABLE
-- ============================================
CREATE TABLE user_stats (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER UNIQUE NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    total_questions_answered INTEGER DEFAULT 0,
    total_correct INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0,
    total_xp INTEGER DEFAULT 0,
    current_level INTEGER DEFAULT 1,
    total_sessions INTEGER DEFAULT 0,
    last_activity TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_user_stats_user ON user_stats(wp_user_id);
CREATE INDEX idx_user_stats_level ON user_stats(current_level);
CREATE INDEX idx_user_stats_activity ON user_stats(last_activity);

-- ============================================
-- USER SUBJECT PROGRESS TABLE
-- ============================================
CREATE TABLE user_subject_progress (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    total_questions_answered INTEGER DEFAULT 0,
    total_correct INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0,
    last_practice_date TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, subject_id)
);

CREATE INDEX idx_subject_progress_user ON user_subject_progress(wp_user_id);
CREATE INDEX idx_subject_progress_subject ON user_subject_progress(subject_id);

-- ============================================
-- USER STREAKS TABLE
-- ============================================
CREATE TABLE user_streaks (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER UNIQUE NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    last_active_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_streaks_user ON user_streaks(wp_user_id);
CREATE INDEX idx_streaks_current ON user_streaks(current_streak DESC);

-- ============================================
-- SESSIONS TABLE
-- ============================================
CREATE TABLE sessions (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    session_id VARCHAR(255) UNIQUE NOT NULL,
    session_type VARCHAR(50) DEFAULT 'MIXED',
    questions_answered INTEGER DEFAULT 0,
    questions_correct INTEGER DEFAULT 0,
    started_at TIMESTAMP DEFAULT NOW(),
    ended_at TIMESTAMP,
    duration_minutes INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON sessions(wp_user_id);
CREATE INDEX idx_sessions_id ON sessions(session_id);
CREATE INDEX idx_sessions_started ON sessions(started_at DESC);

-- ============================================
-- BADGES TABLE
-- ============================================
CREATE TABLE badges (
    id SERIAL PRIMARY KEY,
    code VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    icon_emoji VARCHAR(10) DEFAULT '🏅',
    xp_reward INTEGER DEFAULT 0,
    rarity VARCHAR(50) DEFAULT 'common',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_badges_code ON badges(code);

-- Insert default badges
INSERT INTO badges (code, name, description, icon_emoji, xp_reward, rarity) VALUES
    ('FIRST_QUESTION', 'Première Question', 'Répondre à votre première question', '🎯', 10, 'common'),
    ('QUESTIONS_10', '10 Questions', 'Répondre à 10 questions', '📚', 25, 'common'),
    ('QUESTIONS_50', '50 Questions', 'Répondre à 50 questions', '🎓', 50, 'uncommon'),
    ('QUESTIONS_100', '100 Questions', 'Répondre à 100 questions', '🌟', 100, 'rare'),
    ('QUESTIONS_500', 'Expert', 'Répondre à 500 questions', '👑', 250, 'epic'),
    ('STREAK_7', 'Série de 7 jours', 'Apprendre 7 jours consécutifs', '🔥', 75, 'uncommon'),
    ('STREAK_30', 'Série de 30 jours', 'Apprendre 30 jours consécutifs', '⚡', 200, 'epic'),
    ('STREAK_100', 'Centurion', 'Apprendre 100 jours consécutifs', '💎', 500, 'legendary'),
    ('PERFECTIONIST', 'Perfectionniste', '90% de réussite sur 50+ questions', '✨', 150, 'rare'),
    ('LEVEL_5', 'Niveau 5', 'Atteindre le niveau 5', '⭐', 50, 'common'),
    ('LEVEL_10', 'Niveau 10', 'Atteindre le niveau 10', '🌠', 150, 'rare');

-- ============================================
-- USER BADGES TABLE
-- ============================================
CREATE TABLE user_badges (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    badge_id INTEGER NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
    unlocked_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, badge_id)
);

CREATE INDEX idx_user_badges_user ON user_badges(wp_user_id);
CREATE INDEX idx_user_badges_badge ON user_badges(badge_id);

-- ============================================
-- NOTIFICATION QUEUE TABLE
-- ============================================
CREATE TABLE notification_queue (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    notification_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    channel VARCHAR(50) DEFAULT 'in_app',
    priority VARCHAR(20) DEFAULT 'normal',
    status VARCHAR(50) DEFAULT 'pending',
    data JSONB,
    scheduled_for TIMESTAMP,
    sent_at TIMESTAMP,
    read_at TIMESTAMP,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notification_queue(wp_user_id);
CREATE INDEX idx_notifications_type ON notification_queue(notification_type);
CREATE INDEX idx_notifications_status ON notification_queue(status);
CREATE INDEX idx_notifications_created ON notification_queue(created_at DESC);

-- ============================================
-- DAILY PLANS TABLE
-- ============================================
CREATE TABLE daily_plans (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    plan_date DATE NOT NULL,
    morning_activity JSONB,
    afternoon_activity JSONB,
    evening_activity JSONB,
    morning_completed BOOLEAN DEFAULT FALSE,
    afternoon_completed BOOLEAN DEFAULT FALSE,
    evening_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, plan_date)
);

CREATE INDEX idx_daily_plans_user ON daily_plans(wp_user_id);
CREATE INDEX idx_daily_plans_date ON daily_plans(plan_date DESC);

-- ============================================
-- LEARNING PROFILES TABLE
-- ============================================
CREATE TABLE learning_profiles (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER UNIQUE NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    preferred_time VARCHAR(10) DEFAULT '08:00',
    preferred_duration_minutes INTEGER DEFAULT 15,
    enable_daily_reminder BOOLEAN DEFAULT TRUE,
    enable_streak_reminders BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_learning_profiles_user ON learning_profiles(wp_user_id);

-- ============================================
-- SPACED REPETITION TABLE
-- ============================================
CREATE TABLE spaced_repetition (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    question_id VARCHAR(255) NOT NULL,
    subject_id INTEGER REFERENCES subjects(id),
    ease_factor DECIMAL(3,2) DEFAULT 2.5,
    interval_days INTEGER DEFAULT 1,
    repetitions INTEGER DEFAULT 0,
    next_review_date DATE DEFAULT CURRENT_DATE,
    last_reviewed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, question_id)
);

CREATE INDEX idx_sr_user ON spaced_repetition(wp_user_id);
CREATE INDEX idx_sr_next_review ON spaced_repetition(next_review_date);
CREATE INDEX idx_sr_question ON spaced_repetition(question_id);

-- ============================================
-- QUESTION BANK TABLE
-- ============================================
CREATE TABLE question_bank (
    id SERIAL PRIMARY KEY,
    subject_id INTEGER NOT NULL REFERENCES subjects(id),
    question_text TEXT NOT NULL,
    question_type VARCHAR(50) DEFAULT 'qcm',
    options JSONB,
    correct_answer VARCHAR(10),
    explanation TEXT,
    difficulty VARCHAR(20) DEFAULT 'moyen',
    tags TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_questions_subject ON question_bank(subject_id);
CREATE INDEX idx_questions_type ON question_bank(question_type);
CREATE INDEX idx_questions_difficulty ON question_bank(difficulty);
CREATE INDEX idx_questions_active ON question_bank(is_active);

-- ============================================
-- USER ANSWERS TABLE
-- ============================================
CREATE TABLE user_answers (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id) ON DELETE CASCADE,
    question_id VARCHAR(255) NOT NULL,
    question_type VARCHAR(50),
    is_correct BOOLEAN NOT NULL,
    subject_id INTEGER REFERENCES subjects(id),
    time_taken INTEGER,
    answered_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_answers_user ON user_answers(wp_user_id);
CREATE INDEX idx_answers_question ON user_answers(question_id);
CREATE INDEX idx_answers_answered ON user_answers(answered_at DESC);

-- ============================================
-- SYSTEM LOGS TABLE
-- ============================================
CREATE TABLE system_logs (
    id SERIAL PRIMARY KEY,
    workflow_name VARCHAR(255),
    executed_at TIMESTAMP DEFAULT NOW(),
    status VARCHAR(50),
    reason TEXT,
    error_message TEXT
);

CREATE INDEX idx_system_logs_executed ON system_logs(executed_at DESC);
CREATE INDEX idx_system_logs_status ON system_logs(status);

-- ============================================
-- VIEWS
-- ============================================

-- Vue: Statistiques complètes des utilisateurs
CREATE OR REPLACE VIEW v_user_complete_stats AS
SELECT 
    u.wp_user_id,
    u.wp_display_name,
    u.email,
    us.total_questions_answered,
    us.total_correct,
    us.success_rate,
    us.total_xp,
    us.current_level,
    us.last_activity,
    ust.current_streak,
    ust.longest_streak,
    COUNT(DISTINCT ub.badge_id) as badges_unlocked,
    COUNT(DISTINCT s.id) as sessions_count
FROM users u
LEFT JOIN user_stats us ON u.wp_user_id = us.wp_user_id
LEFT JOIN user_streaks ust ON u.wp_user_id = ust.wp_user_id
LEFT JOIN user_badges ub ON u.wp_user_id = ub.wp_user_id
LEFT JOIN sessions s ON u.wp_user_id = s.wp_user_id
GROUP BY u.wp_user_id, u.wp_display_name, u.email, us.total_questions_answered,
         us.total_correct, us.success_rate, us.total_xp, us.current_level,
         us.last_activity, ust.current_streak, ust.longest_streak;

-- ============================================
-- FUNCTIONS
-- ============================================

-- Fonction: Calculer le niveau à partir de l'XP
CREATE OR REPLACE FUNCTION calculate_level(xp INTEGER)
RETURNS INTEGER AS $$
BEGIN
    RETURN FLOOR(xp / 100) + 1;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Fonction: Mettre à jour updated_at automatiquement
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Créer des triggers pour updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_stats_updated_at BEFORE UPDATE ON user_stats
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_subject_progress_updated_at BEFORE UPDATE ON user_subject_progress
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_streaks_updated_at BEFORE UPDATE ON user_streaks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sessions_updated_at BEFORE UPDATE ON sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notification_queue_updated_at BEFORE UPDATE ON notification_queue
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_daily_plans_updated_at BEFORE UPDATE ON daily_plans
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_learning_profiles_updated_at BEFORE UPDATE ON learning_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_spaced_repetition_updated_at BEFORE UPDATE ON spaced_repetition
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_question_bank_updated_at BEFORE UPDATE ON question_bank
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- GRANTS (si nécessaire)
-- ============================================
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO your_app_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO your_app_user;

-- ============================================
-- DONE
-- ============================================
-- Schema created successfully!
