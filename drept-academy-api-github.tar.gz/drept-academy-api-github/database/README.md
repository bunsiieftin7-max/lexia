# 🗄️ Base de Données - Documentation

Documentation complète du schéma PostgreSQL de Drept Academy.

## 📊 Vue d'Ensemble

- **Type** : PostgreSQL 13+
- **Tables** : 14 tables principales
- **Views** : 1 vue agrégée
- **Functions** : 2 fonctions utilitaires
- **Triggers** : 11 triggers pour updated_at

## 🏗️ Architecture

```
┌─────────────────────────────────────────────┐
│            TABLES PRINCIPALES               │
├─────────────────────────────────────────────┤
│ users                                       │
│ ├── user_stats                             │
│ ├── user_subject_progress                  │
│ ├── user_streaks                           │
│ ├── user_badges                            │
│ ├── user_answers                           │
│ └── learning_profiles                      │
│                                            │
│ subjects                                   │
│ └── question_bank                          │
│                                            │
│ badges                                     │
│ notification_queue                         │
│ daily_plans                                │
│ sessions                                   │
│ spaced_repetition                          │
│ system_logs                                │
└─────────────────────────────────────────────┘
```

## 📋 Tables Détaillées

### 👥 users
Utilisateurs de la plateforme (synchronisés avec WordPress).

```sql
CREATE TABLE users (
    wp_user_id INTEGER PRIMARY KEY,
    wp_display_name VARCHAR(255),
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

**Indexes** : `email`

### 📊 user_stats
Statistiques globales des utilisateurs.

```sql
CREATE TABLE user_stats (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER UNIQUE NOT NULL REFERENCES users(wp_user_id),
    total_questions_answered INTEGER DEFAULT 0,
    total_correct INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0,
    total_xp INTEGER DEFAULT 0,
    current_level INTEGER DEFAULT 1,
    total_sessions INTEGER DEFAULT 0,
    last_activity TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

**Indexes** : `wp_user_id`, `current_level`, `last_activity`

**Calculs** :
- `success_rate` = (total_correct / total_questions_answered) * 100
- `current_level` = FLOOR(total_xp / 100) + 1

### 📚 subjects
Matières de droit disponibles.

```sql
CREATE TABLE subjects (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);
```

**Sujets par défaut** :
1. Droit Civil
2. Droit Pénal
3. Procédure Civile
4. Procédure Pénale
5. Droit Constitutionnel
6. Droit Administratif

### 📈 user_subject_progress
Progression par sujet pour chaque utilisateur.

```sql
CREATE TABLE user_subject_progress (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id),
    subject_id INTEGER NOT NULL REFERENCES subjects(id),
    total_questions_answered INTEGER DEFAULT 0,
    total_correct INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0,
    last_practice_date TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, subject_id)
);
```

**Indexes** : `wp_user_id`, `subject_id`

### 🔥 user_streaks
Séries de jours consécutifs.

```sql
CREATE TABLE user_streaks (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER UNIQUE NOT NULL REFERENCES users(wp_user_id),
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    last_active_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

**Indexes** : `wp_user_id`, `current_streak DESC`

**Milestones** : 7, 30, 100 jours

### 📝 sessions
Sessions d'apprentissage.

```sql
CREATE TABLE sessions (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id),
    session_id VARCHAR(255) UNIQUE NOT NULL,
    session_type VARCHAR(50) DEFAULT 'MIXED',
    questions_answered INTEGER DEFAULT 0,
    questions_correct INTEGER DEFAULT 0,
    started_at TIMESTAMP DEFAULT NOW(),
    ended_at TIMESTAMP,
    duration_minutes INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

**Types** : QCM, FLASHCARD, CHATBOT, MIXED

### 🏆 badges
Définition des badges.

```sql
CREATE TABLE badges (
    id SERIAL PRIMARY KEY,
    code VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    icon_emoji VARCHAR(10) DEFAULT '🏅',
    xp_reward INTEGER DEFAULT 0,
    rarity VARCHAR(50) DEFAULT 'common',
    created_at TIMESTAMP DEFAULT NOW()
);
```

**Raretés** : common, uncommon, rare, epic, legendary

**Badges par défaut** : 11 badges (voir schema.sql)

### 🎖️ user_badges
Badges débloqués par utilisateur.

```sql
CREATE TABLE user_badges (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id),
    badge_id INTEGER NOT NULL REFERENCES badges(id),
    unlocked_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, badge_id)
);
```

### 🔔 notification_queue
File de notifications.

```sql
CREATE TABLE notification_queue (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id),
    notification_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    channel VARCHAR(50) DEFAULT 'in_app',
    priority VARCHAR(20) DEFAULT 'normal',
    status VARCHAR(50) DEFAULT 'pending',
    data JSONB,
    scheduled_for TIMESTAMP,
    sent_at TIMESTAMP,
    read_at TIMESTAMP,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

**Types** : badge_unlocked, streak_milestone, daily_plan_ready, smart_nudge

**Priorités** : low, normal, high

### 📅 daily_plans
Plans d'apprentissage quotidiens.

```sql
CREATE TABLE daily_plans (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id),
    plan_date DATE NOT NULL,
    morning_activity JSONB,
    afternoon_activity JSONB,
    evening_activity JSONB,
    morning_completed BOOLEAN DEFAULT FALSE,
    afternoon_completed BOOLEAN DEFAULT FALSE,
    evening_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, plan_date)
);
```

**Structure JSONB** :
```json
{
  "time": "08:00",
  "activity": "FLASHCARD",
  "subject_id": 1,
  "subject_name": "Droit Civil",
  "duration_minutes": 15,
  "questions_count": 10,
  "difficulty": "moyen"
}
```

### 👤 learning_profiles
Préférences d'apprentissage.

```sql
CREATE TABLE learning_profiles (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER UNIQUE NOT NULL REFERENCES users(wp_user_id),
    preferred_time VARCHAR(10) DEFAULT '08:00',
    preferred_duration_minutes INTEGER DEFAULT 15,
    enable_daily_reminder BOOLEAN DEFAULT TRUE,
    enable_streak_reminders BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

### 🔄 spaced_repetition
Données de répétition espacée (algorithme SM-2).

```sql
CREATE TABLE spaced_repetition (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id),
    question_id VARCHAR(255) NOT NULL,
    subject_id INTEGER REFERENCES subjects(id),
    ease_factor DECIMAL(3,2) DEFAULT 2.5,
    interval_days INTEGER DEFAULT 1,
    repetitions INTEGER DEFAULT 0,
    next_review_date DATE DEFAULT CURRENT_DATE,
    last_reviewed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(wp_user_id, question_id)
);
```

**Algorithme SM-2** :
- `ease_factor` : facilité (min: 1.3, max: 2.5)
- `interval_days` : jours avant prochaine révision
- `repetitions` : nombre de répétitions réussies

### 💾 question_bank
Banque de questions générées par IA.

```sql
CREATE TABLE question_bank (
    id SERIAL PRIMARY KEY,
    subject_id INTEGER NOT NULL REFERENCES subjects(id),
    question_text TEXT NOT NULL,
    question_type VARCHAR(50) DEFAULT 'qcm',
    options JSONB,
    correct_answer VARCHAR(10),
    explanation TEXT,
    difficulty VARCHAR(20) DEFAULT 'moyen',
    tags TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

### 📝 user_answers
Historique des réponses.

```sql
CREATE TABLE user_answers (
    id SERIAL PRIMARY KEY,
    wp_user_id INTEGER NOT NULL REFERENCES users(wp_user_id),
    question_id VARCHAR(255) NOT NULL,
    question_type VARCHAR(50),
    is_correct BOOLEAN NOT NULL,
    subject_id INTEGER REFERENCES subjects(id),
    time_taken INTEGER,
    answered_at TIMESTAMP DEFAULT NOW()
);
```

### 📋 system_logs
Logs système pour les jobs automatiques.

```sql
CREATE TABLE system_logs (
    id SERIAL PRIMARY KEY,
    workflow_name VARCHAR(255),
    executed_at TIMESTAMP DEFAULT NOW(),
    status VARCHAR(50),
    reason TEXT,
    error_message TEXT
);
```

## 🔍 Views

### v_user_complete_stats
Vue agrégée des statistiques complètes.

```sql
CREATE VIEW v_user_complete_stats AS
SELECT 
    u.wp_user_id,
    u.wp_display_name,
    u.email,
    us.total_questions_answered,
    us.total_correct,
    us.success_rate,
    us.total_xp,
    us.current_level,
    us.last_activity,
    ust.current_streak,
    ust.longest_streak,
    COUNT(DISTINCT ub.badge_id) as badges_unlocked,
    COUNT(DISTINCT s.id) as sessions_count
FROM users u
LEFT JOIN user_stats us ON u.wp_user_id = us.wp_user_id
LEFT JOIN user_streaks ust ON u.wp_user_id = ust.wp_user_id
LEFT JOIN user_badges ub ON u.wp_user_id = ub.wp_user_id
LEFT JOIN sessions s ON u.wp_user_id = s.wp_user_id
GROUP BY ...;
```

## ⚙️ Functions

### calculate_level(xp)
Calcule le niveau depuis l'XP.

```sql
CREATE FUNCTION calculate_level(xp INTEGER) RETURNS INTEGER AS $$
BEGIN
    RETURN FLOOR(xp / 100) + 1;
END;
$$ LANGUAGE plpgsql IMMUTABLE;
```

### update_updated_at_column()
Trigger pour mettre à jour `updated_at` automatiquement.

```sql
CREATE FUNCTION update_updated_at_column() RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
```

## 🔧 Maintenance

### Backup
```bash
pg_dump $DATABASE_URL > backup.sql
```

### Restore
```bash
psql $DATABASE_URL < backup.sql
```

### Vacuum
```bash
psql $DATABASE_URL -c "VACUUM ANALYZE;"
```

### Voir les Indexes
```sql
SELECT schemaname, tablename, indexname 
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;
```

### Voir la Taille des Tables
```sql
SELECT 
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

## 📈 Optimisations

### Indexes Actuels
Tous les indexes sont créés automatiquement par `schema.sql`.

### Connection Pooling
Configuré dans `src/config/database.js` :
- Max connections : 20
- Idle timeout : 30s
- Connection timeout : 10s

### Requêtes Optimisées
- Tous les JOINs utilisent des indexes
- Requêtes paramétrées (anti SQL injection)
- Transactions pour opérations multiples

## 🚨 Sécurité

- Toutes les requêtes utilisent des paramètres ($1, $2, etc.)
- Pas de SQL dynamique
- Foreign keys avec ON DELETE CASCADE appropriés
- Contraintes UNIQUE où nécessaire

---

📖 Pour plus d'informations, voir [schema.sql](schema.sql)
