# 🚀 Guide de Déploiement sur Render

Ce guide vous accompagne étape par étape pour déployer Drept Academy API sur Render.

## ⚡ Prérequis

### 1. Compte Render
Créez un compte gratuit sur [render.com](https://render.com)

### 2. Repository GitHub
Forkez ou clonez ce repository sur votre compte GitHub

### 3. Credentials Google

#### A. Google Gemini API
1. Allez sur [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Créez une clé API
3. Copiez la clé (vous en aurez besoin plus tard)

#### B. Google Sheets API
1. Allez sur [Google Cloud Console](https://console.cloud.google.com)
2. Créez un nouveau projet "Drept Academy"
3. Activez "Google Sheets API"
4. Créez un Service Account :
   - Menu : IAM & Admin → Service Accounts
   - Cliquez "Create Service Account"
   - Nom : "drept-academy-sheets"
   - Rôle : pas besoin de rôle particulier
   - Cliquez "Create and Continue" puis "Done"
5. Créez une clé :
   - Cliquez sur le service account créé
   - Onglet "Keys" → "Add Key" → "Create new key"
   - Type : JSON
   - Téléchargez le fichier JSON
6. Ouvrez le fichier JSON et notez :
   - `client_email` (ex: drept-academy-sheets@projet.iam.gserviceaccount.com)
   - `private_key` (commence par -----BEGIN PRIVATE KEY-----)

#### C. Partager vos Google Sheets
1. Ouvrez chaque Google Sheet (Flashcards et QCM)
2. Cliquez sur "Partager"
3. Ajoutez l'email du service account (`client_email`)
4. Donnez l'accès "Lecteur"
5. Cliquez "Envoyer"

---

## 📦 Méthode 1 : Déploiement Automatique (Recommandé)

### Étape 1 : Fork le Repository
1. Cliquez sur "Fork" en haut de cette page GitHub
2. Forkez vers votre compte

### Étape 2 : Déployer sur Render
1. Connectez-vous sur [render.com](https://dashboard.render.com)
2. Cliquez sur "New" → "Blueprint"
3. Connectez votre compte GitHub si ce n'est pas déjà fait
4. Sélectionnez votre fork de `drept-academy-api`
5. Render détecte automatiquement `render.yaml`
6. Nommez votre Blueprint : "Drept Academy"
7. Cliquez sur "Apply"

### Étape 3 : Configurer les Variables Secrètes
Pendant la création, Render vous demandera les variables suivantes :

```bash
GEMINI_API_KEY
# Collez votre clé API Google Gemini

GOOGLE_CLIENT_EMAIL
# Collez le client_email du fichier JSON
# Exemple: drept-academy-sheets@projet.iam.gserviceaccount.com

GOOGLE_PRIVATE_KEY
# Collez la private_key du fichier JSON
# IMPORTANT: Gardez les \n pour les sauts de ligne
# Exemple: -----BEGIN PRIVATE KEY-----\nMIIEvQ...\n-----END PRIVATE KEY-----\n
```

### Étape 4 : Déployer
1. Cliquez sur "Apply Blueprint"
2. Render va créer :
   - Une base de données PostgreSQL
   - Un Web Service avec votre API
3. Attendez la fin du déploiement (5-10 minutes)

### Étape 5 : Initialiser la Base de Données
1. Une fois déployé, allez sur votre Database dans Render
2. Cliquez sur "Connect" → onglet "External Connection"
3. Copiez la commande `psql`
4. Dans votre terminal local :
   ```bash
   # Remplacez <DATABASE_URL> par la commande copiée
   psql <DATABASE_URL> -f database/schema.sql
   ```

### Étape 6 : Tester
```bash
# Remplacez your-app par le nom de votre app Render
curl https://your-app.onrender.com/api/health
```

Vous devriez voir : `{"status":"ok",...}`

**✅ C'est fait !** Votre API est déployée !

---

## 🛠️ Méthode 2 : Déploiement Manuel

### Étape 1 : Créer la Base de Données
1. Sur Render Dashboard : "New" → "PostgreSQL"
2. Configuration :
   - Name : `drept-academy-db`
   - Database : `drept_academy`
   - User : `drept_academy_user`
   - Region : Frankfurt (ou plus proche de vous)
   - Plan : Starter (gratuit)
3. Cliquez "Create Database"
4. Notez l'URL de connexion (Internal ou External)

### Étape 2 : Créer le Web Service
1. Sur Render Dashboard : "New" → "Web Service"
2. Connectez votre repository GitHub
3. Configuration :
   - Name : `drept-academy-api`
   - Region : Frankfurt
   - Branch : `main`
   - Root Directory : (vide)
   - Runtime : Node
   - Build Command : `npm install`
   - Start Command : `npm start`
   - Plan : Starter (gratuit)

### Étape 3 : Configurer les Variables d'Environnement
Dans l'onglet "Environment", ajoutez :

```bash
NODE_ENV=production
PORT=3000

# Database (choisir votre DB créée à l'étape 1)
DATABASE_URL=<sélectionner dans la liste>

# Google Gemini
GEMINI_API_KEY=your_gemini_key_here

# Google Sheets
GOOGLE_CLIENT_EMAIL=your-service-account@project.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nyour_private_key_here\n-----END PRIVATE KEY-----\n"
FLASHCARD_SHEET_ID=178vqdJKMbuc2NWjPF5Y9vKhPHHhyuYGH5DZj6pgXRE4
QCM_SHEET_ID=1bSoiPiMhIpHKTx4cv-K2XMroZJ5dchuTr_qKAi3OO7M

# Configuration
ALLOWED_ORIGINS=https://drept-academy.com
ENABLE_CRON_JOBS=true
LOG_LEVEL=info
```

### Étape 4 : Déployer
1. Cliquez "Create Web Service"
2. Render va construire et déployer (5-10 minutes)

### Étape 5 : Initialiser la Base de Données
```bash
# Dans votre terminal
psql <DATABASE_URL> -f database/schema.sql
```

### Étape 6 : Vérifier
```bash
curl https://your-app.onrender.com/api/health/detailed
```

---

## 🧪 Tests Post-Déploiement

### 1. Health Check
```bash
curl https://your-app.onrender.com/api/health
```

### 2. Créer un Utilisateur Test
```bash
psql $DATABASE_URL << EOF
INSERT INTO users (wp_user_id, wp_display_name, email) 
VALUES (1, 'Test User', 'test@example.com');
EOF
```

### 3. Tester un Endpoint
```bash
curl -X POST https://your-app.onrender.com/api/stats/update \
  -H "Content-Type: application/json" \
  -d '{
    "wp_user_id": 1,
    "is_correct": true,
    "subject_id": 1,
    "question_id": "test_q1"
  }'
```

### 4. Récupérer les Stats
```bash
curl https://your-app.onrender.com/api/stats/user/1
```

### 5. Tester une Question
```bash
curl -X POST https://your-app.onrender.com/api/questions/flashcard \
  -H "Content-Type: application/json" \
  -d '{"query": "droit civil"}'
```

---

## 🔧 Configuration Avancée

### Domaine Personnalisé
1. Render Dashboard → Votre Service → Settings → Custom Domain
2. Ajoutez votre domaine
3. Configurez les DNS selon les instructions Render

### Backups Automatiques
1. Render Dashboard → Votre Database → Backups
2. Activez "Enable Automatic Backups"

### Alertes
1. Render Dashboard → Votre Service → Settings → Alerts
2. Configurez les alertes email

### Logs
```bash
# Voir les logs en temps réel
# Render Dashboard → Votre Service → Logs
```

### Scaling
Pour plus de performance :
1. Render Dashboard → Votre Service → Settings
2. Changez le Plan (Standard ou Pro)

---

## 🐛 Dépannage

### Erreur : "Google Sheets API not configured"
**Cause** : Variables `GOOGLE_CLIENT_EMAIL` ou `GOOGLE_PRIVATE_KEY` manquantes ou incorrectes

**Solution** :
1. Vérifiez que les variables sont définies
2. Vérifiez que `GOOGLE_PRIVATE_KEY` contient les `\n` pour les sauts de ligne
3. Vérifiez que les Sheets sont partagés avec le service account

### Erreur : "Database connection failed"
**Cause** : `DATABASE_URL` incorrect ou DB non accessible

**Solution** :
1. Vérifiez que `DATABASE_URL` est correctement configuré
2. Vérifiez que la DB est dans le même projet Render
3. Testez la connexion : `psql $DATABASE_URL -c "SELECT 1"`

### Erreur : "Service AI non configuré"
**Cause** : `GEMINI_API_KEY` manquante ou invalide

**Solution** :
1. Vérifiez que la clé est définie dans les variables d'environnement
2. Testez la clé sur Google AI Studio
3. Générez une nouvelle clé si nécessaire

### Les Jobs ne s'exécutent pas
**Cause** : `ENABLE_CRON_JOBS` non défini ou le plan Render gratuit a des limitations

**Solution** :
1. Vérifiez `ENABLE_CRON_JOBS=true`
2. Vérifiez les logs pour voir si les jobs démarrent
3. Sur le plan gratuit, les instances peuvent dormir après inactivité

### Performances lentes
**Solutions** :
1. Vérifier les logs pour les requêtes lentes
2. Vérifier les indexes de la DB : `\d+ table_name` dans psql
3. Augmenter le plan Render
4. Ajouter du caching (Redis)

---

## 📊 Monitoring

### Métriques Render
- CPU usage
- Memory usage
- Request rate
- Response time

Accessible via : Render Dashboard → Votre Service → Metrics

### Health Checks
```bash
# Simple
curl https://your-app.onrender.com/api/health

# Détaillé avec métriques
curl https://your-app.onrender.com/api/health/detailed

# Database
curl https://your-app.onrender.com/api/health/database
```

---

## 🚀 Mise en Production

### Checklist avant production :

- [ ] Variables d'environnement configurées
- [ ] Database initialisée avec schema.sql
- [ ] Health checks passent
- [ ] Tous les endpoints testés
- [ ] Backups DB activés
- [ ] Domaine personnalisé configuré (optionnel)
- [ ] Monitoring configuré
- [ ] Logs consultés pour vérifier absence d'erreurs

### Intégration avec WordPress

```javascript
// Dans votre frontend WordPress
const API_URL = 'https://your-app.onrender.com/api';

// Exemple : Mettre à jour les stats
async function updateStats(userId, isCorrect) {
  const response = await fetch(`${API_URL}/stats/update`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      wp_user_id: userId,
      is_correct: isCorrect,
      subject_id: 1,
      question_id: 'q_' + Date.now()
    })
  });
  return response.json();
}
```

---

## 🆘 Support

- 📖 [Documentation complète](../README.md)
- 🐛 [Ouvrir une issue](https://github.com/votre-username/drept-academy-api/issues)
- 💬 [Discussions](https://github.com/votre-username/drept-academy-api/discussions)
- 📧 [Render Support](https://render.com/support)

---

**Félicitations ! Votre API est maintenant déployée ! 🎉**
