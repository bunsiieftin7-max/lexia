---
name: Bug Report
about: Signaler un bug
title: '[BUG] '
labels: bug
assignees: ''
---

## 🐛 Description du Bug
<!-- Description claire et concise du bug -->

## 📋 Pour Reproduire
Étapes pour reproduire le comportement :
1. Aller sur '...'
2. Cliquer sur '...'
3. Voir l'erreur

## ✅ Comportement Attendu
<!-- Description de ce qui devrait se passer -->

## 📸 Screenshots
<!-- Si applicable, ajoutez des screenshots -->

## 🖥️ Environnement
- OS: [ex: Ubuntu 22.04]
- Node: [ex: 18.17.0]
- PostgreSQL: [ex: 13.8]
- Version API: [ex: 1.0.0]

## 📝 Logs
```
Collez les logs pertinents ici
```

## 🔍 Contexte Additionnel
<!-- Toute autre information pertinente -->
